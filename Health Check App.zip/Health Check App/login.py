import json
import requests
import streamlit as st
from sqlalchemy import create_engine
from snowflake.sqlalchemy import URL
import base64
import os
from PIL import Image
from streamlit_extras.switch_page_button import switch_page
import yaml

Background = os.path.join(os.path.dirname(os.path.abspath(__file__)), f"bg.jpg")
# @st._cache_data(allow_output_mutation=True)
# logo=Image.open('bl.png')
# st.image(logo)
hide_st_style = """ 
    <style> 
    #MainMenue {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    </style>
    """
st.markdown(hide_st_style, unsafe_allow_html=True)
css = """
<style>
section.main > div:has(~ footer ) {
    padding-bottom: 5px;
}

</style>
"""
st.markdown(css, unsafe_allow_html=True)

no_sidebar_style = """
    <style>
        [data-testid="stSidebar"] {
        display: none;
        }
    </style>
"""
st.markdown(no_sidebar_style, unsafe_allow_html=True)



def get_base64_of_bin_file(bin_file):
    with open(bin_file, 'rb') as f:
        data = f.read()
    return base64.b64encode(data).decode()

def set_png_as_page_bg(png_file):
    bin_str = get_base64_of_bin_file(png_file)
    page_bg_img = '''
    <style>
    .stApp {
    background-image: url("data:image/png;base64,%s");
    background-size: cover;
    }
    
    
    
    [id="root"]{
    
    }
    </style>
    ''' % bin_str

    st.markdown(page_bg_img, unsafe_allow_html=True)
    return

set_png_as_page_bg('bg.jpg')

#
# def load_lottieurl(url:str):
#     r=requests.get(url)
#     if r.status_code != 200:
#         return None
#     return r.json()
# #
# loti=load_lottieurl("https://lottie.host/?file=09db2343-fdd9-4211-9f95-d4a8a2f48b7a/PYrOi53hCB.json")
# st_lottie(loti)


def load_lottiefile(filepath:str):
    with open(filepath,"r") as f:
        return json.load(f)
loti=load_lottiefile("76888-color-data-analysis.json")
# st_lottie(loti,)

st.markdown("""
<style>
[data-testid="stImage"]{
margin-top:50mm;
margin-left:-120mm;
}

.css-10trblm.e16nr0p30{
text-transform: uppercase;
	background: linear-gradient(to right, #30CFD0 0%, #330867 100%);
	-webkit-background-clip: text;
	-webkit-text-fill-color: transparent;
	font: {
		size: 20vw;
		family: $font;
	};
text-align: center;
</style>
""",unsafe_allow_html=True)


st.title('SNOWFLAKE HEALTH CHECK')

with st.form("my_form"):

   st.subheader("Snowflake Credentials")
   user=st.text_input('**user**')
   password=st.text_input('**password**',type='password')
   account=st.text_input('**account**')
   warehouse=st.text_input('**warehouse**')
#    if 'user' not in st.session_state:
#        st.session_state['user']=user

#    if 'password' not in st.session_state:
#        st.session_state['password']=password

#    if 'account' not in st.session_state:
#        st.session_state['account']=account

#    if 'warehouse' not in st.session_state:
#        st.session_state['warehouse']=warehouse
   col1, col2, col3 = st.columns([1.5,1,1])
   submitted=col2.form_submit_button('**login**')


   
   if submitted:
       
    data = dict(
    user=user,
    password=password,
    account=account,
    warehouse=warehouse,
    )

    with open('login credentials.yml', 'w') as outfile: 
             yaml.dump(data, outfile, default_flow_style=False)

    with open(r'C:\Users\Sunil\OneDrive - Boolean Data Systems\Desktop\HC update\login credentials.yml') as file:
            doc = yaml.load(file, Loader=yaml.FullLoader)
    url = URL(
            user=doc["user"],
            password=doc["password"],
            account=doc["account"],
            warehouse=doc["warehouse"]
        )
    
    engine = create_engine(url)
    connection = engine.connect()
    if connection:
           st.success("Connected sucessfully")
           switch_page("Dashboard_")
    else:
           st.error("fail to Please try again")


st.markdown("""
<style>

[data-testid="stForm"]{
 border-radius: 25px;
 top:40px;
 margin-left:500px;
 box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
 background:white;
 backdrop-filter: blur(30px);
 width:500px;
 position:static;

}
.css-10trblm.e16nr0p30{
text-align: center;
}

</style>
""",unsafe_allow_html=True)

# st.markdown("""
# <style>
# .css-10trblm.e16nr0p30 {
#  border: none;
#  color: #fff;
#  background-image: linear-gradient(30deg, #0400ff, #4ce3f7);
#  border-radius: 20px;
#  background-size: 100% auto;
#  font-family: inherit;
#  font-size: 17px;
#  padding: 0.6em 1.5em;
# }
#
# .css-1x8cf1d.edgvbvh10:hover {
#  background-position: right center;
#  background-size: 200% auto;
#  -webkit-animation: pulse 2s infinite;
#  animation: pulse512 1.5s infinite;
# }
#
# </style>
# """,unsafe_allow_html=True)