import pandas as pd
import streamlit as st
import numpy as np
import pathlib
import os
from sqlalchemy import create_engine
from snowflake.sqlalchemy import URL
import snowflake.connector
import boto3
from PIL import Image
from streamlit.components.v1 import html
import streamlit_extras
from streamlit_extras.switch_page_button import switch_page
import base64
import time
import pandas as pd
import os
from datetime import datetime
import pathlib
from sqlalchemy import create_engine
import time
from datetime import datetime
from sqlalchemy.engine import URL
import boto3
import logging,sys
from streamlit_option_menu import option_menu
from sqlalchemy import create_engine
from snowflake.sqlalchemy import URL
import plotly.express as px
import matplotlib.pyplot as plt
from streamlit_extras.metric_cards import style_metric_cards
from streamlit_extras.no_default_selectbox import selectbox
import seaborn as sns
import matplotlib.pyplot as plt
from streamlit_extras.altex import line_chart
from datetime import datetime
import plotly.express as px
import plotly.figure_factory as ff
from streamlit_extras.stoggle import stoggle
from streamlit_extras.mandatory_date_range import date_range_picker
from datetime import datetime
from streamlit_extras.no_default_selectbox import selectbox
import altair as alt
from streamlit_extras.mandatory_date_range import date_range_picker
from streamlit_extras.chart_container import chart_container
from streamlit_extras.app_logo import add_logo
import graphviz
from st_aggrid import AgGrid
import yaml

st.set_page_config(page_title=None, page_icon=None, layout="wide", initial_sidebar_state="auto", menu_items=None)
st.markdown("""
<style>
.css-wjbhl0.e1fqkh3o9{
visibility: hidden;}
.css-1s3y5qe.e1fqkh3o8{
visibility: hidden;
.css-9s5bis.edgvbvh3{
visibility: hidden;
}
.css-79elbk.e1fqkh3o10{
width: 10px;
height: 10px;

}

</style>""",unsafe_allow_html=True)



st.markdown("""
<style>
.user-select-none.svg-container{
    box-shadow: 0 4px 8px 0 rgb(0 0 0 / 20%), 0 6px 20px 0 rgb(0 0 0 / 19%);
}
[data-testid="stArrowVegaLiteChart"]{
    box-shadow: 0 4px 8px 0 rgb(0 0 0 / 20%), 0 6px 20px 0 rgb(0 0 0 / 19%);
}

</style>
""",unsafe_allow_html=True)

# html("""
# <script>
# const element = window.parent.document.querySelectorAll('.e16fv1kl3')
#
# element[3].style.color = 'yellow'
# </script>
# """)

if st.sidebar.button("Logout"):
    switch_page("login")
with open(r'C:\Users\Sunil\OneDrive - Boolean Data Systems\Desktop\HC update\login credentials.yml') as file:
            doc = yaml.load(file, Loader=yaml.FullLoader)
url = URL(
            user=doc["user"],
            password=doc["password"],
            account=doc["account"],
            warehouse=doc["warehouse"]
        )
    
engine = create_engine(url)
connection = engine.connect()
selected = option_menu(
    menu_title=None, #required
    options=[ "Account" ,"Storage", "Warehouse",'Role Management',"Miscellaneous",], #required
    # icons= [ " house" ,"book", "envelope"], #optional
    default_index=0,
    orientation="horizontal")

with st.sidebar:
    add_logo("pages/bl2.png")
# /usr/share/nginx/html/HC/pages/bl2.png
# C:/Users/Vikas Sony/Desktop/HC_1/HC/pages/bl2.png

st.markdown("""
<style>
.css-tw2vp1.e1tzin5v0{
top:-75px;
}

</style>""",unsafe_allow_html=True)

@st.cache_data
def Account():
    # large_tables=pd.read_sql(f"""
    # select  sum (CREDITS_USED) as total_credits, sum(CREDITS_USED_COMPUTE) as compute_credits,
    # sum(CREDITS_USED_CLOUD_SERVICES) as cloud_credits from "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY" ;""",connection)



    large_tables_=pd.read_sql(f"""select  round(sum(s.STORAGE_BYTES/1000000000),2) as Total_storage_bytes_in_gb,
    round(sum(b.AVERAGE_STAGE_BYTES/1000000000),2) as Total_STAGE_BYTES_in_gb,
    round(sum(s.FAILSAFE_BYTES/1000000000),2) as Total_FAILSAFE_BYTES_in_gb
    from SNOWFLAKE.ACCOUNT_USAGE.STAGES a
    join "SNOWFLAKE"."ACCOUNT_USAGE"."STAGE_STORAGE_USAGE_HISTORY" b
    on date(a.created)=b.USAGE_DATE
    join "SNOWFLAKE"."ACCOUNT_USAGE"."STORAGE_USAGE" s
    on date(a.created)=s.USAGE_DATE
    join "SNOWFLAKE"."ACCOUNT_USAGE"."TABLE_STORAGE_METRICS" t
    on date(t.TABLE_ENTERED_FAILSAFE) = s.USAGE_DATE
    join "SNOWFLAKE"."ACCOUNT_USAGE"."METERING_DAILY_HISTORY" m
    on date(a.created)=m.USAGE_DATE
    where a.deleted is null and a.STAGE_TYPE= 'Internal Named' 
    order by s.USAGE_DATE asc;""",connection)

    current_region_and_edition  = pd.read_sql("""select distinct SERVICE_LEVEL,REGION from SNOWFLAKE.ORGANIZATION_USAGE.USAGE_IN_CURRENCY_DAILY where REGION= current_region()""",connection)

    total_no_of_users  = pd.read_sql("""SELECT COUNT(*) as users FROM "SNOWFLAKE"."ACCOUNT_USAGE"."USERS" where  DELETED_ON is null""",connection)
    # total no of warehouses

    # warehouse credits consumed per day
    large_tables = pd.read_sql(f"""
           select  sum (CREDITS_USED) as total_credits, sum(CREDITS_USED_COMPUTE) as compute_credits, 
           sum(CREDITS_USED_CLOUD_SERVICES) as cloud_credits from "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY" ;""",
                               connection)
    # total no of ROLES

    total_no_of_ROLES  = pd.read_sql("""SELECT COUNT(*) as  ROLES  FROM "SNOWFLAKE"."ACCOUNT_USAGE"."ROLES" where DELETED_ON is null""",connection)

    # # total no of Reader Accounts
    # total_no_of_readers_account  = pd.read_sql("""SHOW MANAGED ACCOUNTS;
    # """,connection)
    # st.write(total_no_of_readers_account.groupby('name'))

    # Storage and Compute Effective Rate(USD)
    EFFECTIVE_RATE_STORAGE = pd.read_sql("""
    select DATE,ORGANIZATION_NAME,ACCOUNT_NAME,REGION,SERVICE_LEVEL,USAGE_TYPE,EFFECTIVE_RATE,SERVICE_TYPE from SNOWFLAKE.ORGANIZATION_USAGE.RATE_SHEET_DAILY
    where date>= DATEADD(day,-3, GETDATE()) and SERVICE_TYPE='STORAGE' order by EFFECTIVE_RATE desc limit 1;
    """,connection)

    EFFECTIVE_RATE_COMPUTE = pd.read_sql("""
    select DATE,ORGANIZATION_NAME,ACCOUNT_NAME,REGION,SERVICE_LEVEL,USAGE_TYPE,EFFECTIVE_RATE,SERVICE_TYPE from SNOWFLAKE.ORGANIZATION_USAGE.RATE_SHEET_DAILY
    where date>= DATEADD(day,-3, GETDATE()) and SERVICE_TYPE='COMPUTE' order by EFFECTIVE_RATE desc limit 1; 
    """,connection)


    Total_Storage_Consumed= pd.read_sql("""
    select d.USAGE_DATE,          
    ((sum(d.AVERAGE_DATABASE_BYTES/(1024*1024*1024)))+(sum(d.AVERAGE_FAILSAFE_BYTES/(1024*1024*1024)))+sum(s.AVERAGE_STAGE_BYTES/(1024*1024*1024)))
    as "total_storage"
    from SNOWFLAKE.ACCOUNT_USAGE.DATABASE_STORAGE_USAGE_HISTORY d
    join SNOWFLAKE.ACCOUNT_USAGE.STAGE_STORAGE_USAGE_HISTORY s on s.USAGE_DATE=d.USAGE_DATE
    where d.USAGE_DATE>=DATEADD(day, -1, CURRENT_DATE())
    group by d.USAGE_DATE,s.USAGE_DATE;
    """, connection)

    Total_no_queries= pd.read_sql("""
    SELECT count(QUERY_ID) AS no_of_queries from  SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY ;
    """, connection)

    large_query_percentage= pd.read_sql("""
    select count(BYTES_WRITTEN_TO_RESULT/1000000000) as total,
    count(CASE WHEN (BYTES_WRITTEN_TO_RESULT/1000000000) > 1 THEN (BYTES_WRITTEN_TO_RESULT/1000000000)  END) AS greater,
    count(CASE WHEN (BYTES_WRITTEN_TO_RESULT/1000000000) < 1 THEN (BYTES_WRITTEN_TO_RESULT/1000000000)  END) AS lower,
    (greater/total)*100 large_query_percentage  ,(lower/total)*100 small_query_percentage   
    from SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
        """, connection)


    small_query_percentage= pd.read_sql("""
    select count(BYTES_WRITTEN_TO_RESULT/1000000000) as total,
    count(CASE WHEN (BYTES_WRITTEN_TO_RESULT/1000000000) > 1 THEN (BYTES_WRITTEN_TO_RESULT/1000000000)  END) AS greater,
    count(CASE WHEN (BYTES_WRITTEN_TO_RESULT/1000000000) < 1 THEN (BYTES_WRITTEN_TO_RESULT/1000000000)  END) AS lower,
    (greater/total)*100 large_query_percentage  ,(lower/total)*100 small_query_percentage   
    from SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY;
    """, connection)



    col1,col2=st.columns(2)
    col1.metric(label="Current Edition", value=current_region_and_edition['service_level'][0])
    col2.metric(label="Current Region", value=current_region_and_edition['region'][0])

    style_metric_cards()

    DB = pd.read_sql(""" select DATABASE_NAME from "SNOWFLAKE"."ACCOUNT_USAGE"."DATABASES" where deleted is null """,connection)
    database=DB['database_name'].tolist()
    if 'database' not in st.session_state:
        st.session_state['database'] = database

   
    # col1,col2,col3=st.columns(3)
    # col1.metric(label="Effective Rate(Storage/TB)", value=f"${EFFECTIVE_RATE_STORAGE['effective_rate'][0]}")
    # col2.metric(label="Storage Consumed(GB)", value=round(Total_Storage_Consumed['total_storage'][0], 2))
    # col3.metric(label="Total Storage Cost", value=round(((EFFECTIVE_RATE_STORAGE['effective_rate'][0])/1000)*(Total_Storage_Consumed['total_storage'][0]), 2))

    # col1,col2,col3=st.columns(3)
    # col1.metric(label="Effective Rate(Compute)", value=f"${EFFECTIVE_RATE_COMPUTE['effective_rate'][0]}")
    # col2.metric(label="Total Compute and Cloud Credits", value=round(large_tables['total_credits'][0], 2))
    # col3.metric(label="Total Compute Cost", value=round((EFFECTIVE_RATE_COMPUTE['effective_rate'][0])*(large_tables['total_credits'][0]), 2))
    


    col1,col2=st.columns(2)
    col1.metric(label="Total No Of Users", value=total_no_of_users['users'])
    col2.metric(label="Total No Of Roles", value=total_no_of_ROLES['roles'])
    # col3.metric(label="Total No Of Reader Account", value=total_no_of_readers_account['total_reader_accounts'])

    col1,col2,col3=st.columns(3)
    col1.metric(label="Total Queries", value=Total_no_queries['no_of_queries'])
    col2.metric(label="Large Queries Percentage", value=large_query_percentage['large_query_percentage'])
    col3.metric(label="Small Queries Percentage", value=small_query_percentage['small_query_percentage'])
    
    style_metric_cards()
    # database age graph-----------------------------------------
    ssgcol1,ssgcol2 =st.columns(2)
    with ssgcol1:
        database=pd.read_sql(f""" SELECT a.DATABASE_NAME, DATEDIFF(day, min(date(a.CREATED)), current_date) as age,
                            nvl(cast(DATEDIFF(day, date(max(b.USAGE_DATE)), current_date) as varchar),'never used') as last_used
                            from "SNOWFLAKE"."ACCOUNT_USAGE"."DATABASES" a left join
                            "SNOWFLAKE"."ACCOUNT_USAGE"."DATABASE_STORAGE_USAGE_HISTORY" b
                            on  a.DATABASE_NAME=b.DATABASE_NAME
                            where a.DELETED is null
                            group by a.DATABASE_NAME
                            order by age DESC limit 10;""",connection)
        fig=px.bar(database, y='age', x='database_name',title="Database Age",width=700, height=370,labels={"database_name":"Databases","age":"Age"},
                    hover_name='database_name',hover_data=['last_used'])
        fig.update_layout(xaxis={"categoryorder": "total descending"})
        st.write(fig)

    #database_storage--------------------------------------------
    with ssgcol2:

        database_storage = pd.read_sql("""
        select b.DATABASE_NAME,round(sum((a.AVERAGE_DATABASE_BYTES/1000000000)),2)+round(sum((a.AVERAGE_FAILSAFE_BYTES/1000000000)),2) as AVERAGE_DATABASE_GB
        from "SNOWFLAKE"."ACCOUNT_USAGE"."DATABASES" b left join
        "SNOWFLAKE"."ACCOUNT_USAGE"."DATABASE_STORAGE_USAGE_HISTORY" a
        on b.DATABASE_NAME = a.DATABASE_NAME
        where a.usage_date=dateadd(day,-1,current_date) and b.DELETED is null
        group by b.DATABASE_NAME;
        """,connection)
        database_storage=pd.DataFrame(database_storage)

        fig=px.pie(database_storage,hole = 0.5,values='average_database_gb',names='database_name',title="Database Storage",width=700, height=370)
        # fig.update_layout(width=500,height=500,margin=dict(l=1,r=1,b=1,t=1))
        st.write(fig)

    #tabels----------------------------------
    with ssgcol1:
        table_type=pd.read_sql(f""" select table_type,count(table_type) NO_OF_TABLES,nvl(IS_TRANSIENT,'NO') as IS_TRANSIENT
        from "SNOWFLAKE"."ACCOUNT_USAGE"."TABLES"where 
        DELETED is null and TABLE_TYPE ='BASE TABLE'or TABLE_TYPE = 'EXTERNAL TABLE'
        group by table_type,IS_TRANSIENT;""",connection)

        table_types =pd.DataFrame(table_type)
        for x in range(len(table_types['is_transient'])):
            if table_types['is_transient'][x]  == 'YES':
                table_types['table_type'][x]='BASE TABLE TRANSIENT'

        fig=px.bar( y=table_types['no_of_tables'], x=table_types['table_type'],title="Table Types",width=700, height=370,labels={"x":"Table Type","y":"No of Tables"})
        fig.update_layout(xaxis={"categoryorder": "total descending"})
        st.write(fig)

    #IDLE_USERS_FROM_MONTH----------------------------------
    with ssgcol2:
        IDLE_USERS_FROM_MONTH =pd.read_sql(f""" SELECT NAME,DATEDIFF(DAY,DATE(LAST_SUCCESS_LOGIN),CURRENT_DATE) LAST_DAY_LOGIN
        FROM SNOWFLAKE.ACCOUNT_USAGE.USERS 
        WHERE LAST_SUCCESS_LOGIN < DATEADD(month, -1, CURRENT_TIMESTAMP()) 
        AND DELETED_ON IS NULL limit 10;""",connection)
        fig=px.bar(IDLE_USERS_FROM_MONTH, y='last_day_login', x='name',title="Idle Users Since 30 Days",width=700, height=370,
                   labels={"name":"Name","last_day_login":"Last Day Login"})
        fig.update_layout(xaxis={"categoryorder": "total descending"})
        st.write(fig)





@st.cache_data
def Storage():
    active_bytes_for_failsafe = pd.read_sql(
        """select round(sum(FAILSAFE_BYTES/1000000000),2) as sum from SNOWFLAKE.ACCOUNT_USAGE.TABLE_STORAGE_METRICS where TABLE_ENTERED_FAILSAFE is not null """,
        connection)

    # materialized view consumed bytes

    total_materialized_view_consumed_bytes = pd.read_sql(""" SELECT nvl(SUM(BYTES/1000000000),0) as BYTES
       FROM SNOWFLAKE.ACCOUNT_USAGE.TABLES WHERE CREATED >= dateadd(month,-1,current_timestamp())
        and TABLE_TYPE ='MATERIALIZED VIEW' and deleted is null; """, connection)
    # permanant tables active bytes

    permanant_tables_active_bytes = pd.read_sql(""" select  round(sum(ACTIVE_BYTES/1000000000),2) as sum from SNOWFLAKE.ACCOUNT_USAGE.TABLE_STORAGE_METRICS where 
       TABLE_DROPPED is null and IS_TRANSIENT='NO' """, connection)

    # active bytes for transient tables

    active_bytes_for_transient_tables = pd.read_sql(""" select  nvl(round(sum(ACTIVE_BYTES/1000000000),2),0) as sum from SNOWFLAKE.ACCOUNT_USAGE.TABLE_STORAGE_METRICS
        where TABLE_DROPPED is null and IS_TRANSIENT='YES'; """, connection)
    DATABASE_NAME = pd.read_sql(
        """select count("DATABASE_NAME") as database_count from "SNOWFLAKE"."ACCOUNT_USAGE"."DATABASES" where deleted is null""",
        connection)
    SCHEMA_NAME = pd.read_sql(
        'select count(schema_name) as schema_count from  snowflake.account_usage.schemata where deleted is null;',
        connection)
    TABLE_NAME = pd.read_sql(
        'select count("TABLE_NAME") as table_count from "SNOWFLAKE"."ACCOUNT_USAGE"."TABLES" where deleted is null;',
        connection)
    VIEW_NAME = pd.read_sql(
        'select count("TABLE_NAME") as view_count from  "SNOWFLAKE"."ACCOUNT_USAGE"."VIEWS" where deleted is null;',
        connection)
    AVERAGE_STAGE_BYTES = pd.read_sql(
        'SELECT ROUND(sum(AVERAGE_STAGE_BYTES/1000000000),2) AVERAGE_STAGE_BYTES FROM  '
        'SNOWFLAKE.ACCOUNT_USAGE.STAGE_STORAGE_USAGE_HISTORY WHERE USAGE_DATE=DATEADD(DAY,-1,CURRENT_DATE)',
        connection)

    mcol1,mcol2,mcol3,mcol4=st.columns(4)
    mcol1.metric(label="Total Number of DataBases", value=DATABASE_NAME['database_count'], )
    mcol2.metric(label="Total Number of Schemas", value=SCHEMA_NAME['schema_count'])
    mcol3.metric(label="Total Number of Tables", value=TABLE_NAME['table_count'])
    mcol4.metric(label="Total Number of Views", value=VIEW_NAME['view_count'])
    
    
    mcol1,mcol2,mcol3=st.columns(3)
    mcol1.metric(label="Total Active Bytes for Permanent Tables (GB)", value=permanant_tables_active_bytes['sum'])
    mcol2.metric(label="Total Active Bytes for Transient Tables (GB)", value=active_bytes_for_transient_tables['sum'])
    mcol3.metric(label="Total Active Bytes for Failsafe (GB)", value=active_bytes_for_failsafe['sum'])

    mcol1,mcol2=st.columns(2)
    mcol1.metric(label="Total Materialized Views Consumption (GB)", value=total_materialized_view_consumed_bytes['bytes'])
    mcol2.metric(label="Total Average Bytes for Stage (GB)", value=AVERAGE_STAGE_BYTES['average_stage_bytes'])

    style_metric_cards()

    col1, col2 = st.columns(2)

    with col1:
        db = pd.read_sql("""
           select USAGE_DATE,(sum(AVERAGE_DATABASE_BYTES/(1024*1024*1024))) as "AVERAGE_DATABASE_BYTES",(sum(AVERAGE_FAILSAFE_BYTES/(1024*1024*1024))) as "AVERAGE_FAILSAFE_BYTES"
           from SNOWFLAKE.ACCOUNT_USAGE.DATABASE_STORAGE_USAGE_HISTORY 
           where USAGE_DATE>=DATEADD(day, -15, CURRENT_DATE())
           group by USAGE_DATE;
           """, connection)

        sc = pd.read_sql("""
           select USAGE_DATE,sum(AVERAGE_STAGE_BYTES/(1024*1024*1024)) as "AVERAGE_STAGE_BYTES" from SNOWFLAKE.ACCOUNT_USAGE.STAGE_STORAGE_USAGE_HISTORY 
           where USAGE_DATE>=DATEADD(day, -15, CURRENT_DATE())
           group by USAGE_DATE;
                       """, connection)

        total = pd.merge(db, sc, on=["usage_date", "usage_date"])

        cc = total.assign(total=total.average_database_bytes + total.average_failsafe_bytes + total.average_stage_bytes)

        fig_3 = px.bar(cc, x='usage_date',
                       y=['average_database_bytes', 'average_failsafe_bytes', 'average_stage_bytes'], width=700,
                       height=370,
                       hover_name="total", labels={"usage_date": "Usage Date",
                                                   "average_database_bytes": "Average Database Bytes",
                                                   "average_failsafe_bytes": "Average Failsafe Bytes",
                                                   "average_stage_bytes": "Average Stage Bytes"},
                       title='Storage Consumption Since 15 Days')
        fig_3.update_layout( legend_title="    ")
        st.write(fig_3)

    with col2:
        # top 10  databases by size

        top_10_databases_by_size = pd.read_sql(f"""            
        select b.DATABASE_NAME,round(sum((a.AVERAGE_DATABASE_BYTES/1000000000)),2)+round(sum((a.AVERAGE_FAILSAFE_BYTES/1000000000)),2) as AVERAGE_DATABASE_GB
        from "SNOWFLAKE"."ACCOUNT_USAGE"."DATABASES" b left join
        "SNOWFLAKE"."ACCOUNT_USAGE"."DATABASE_STORAGE_USAGE_HISTORY" a
        on b.DATABASE_NAME = a.DATABASE_NAME
        where a.usage_date=dateadd(day,-1,current_date) and b.DELETED is null
        group by b.DATABASE_NAME;  """, connection)

        top_10_databases_by_size1 = px.bar(top_10_databases_by_size,x='database_name',
                                           y='average_database_gb', width=700, height=370,
                                           labels={"database_name": "Database Name", "average_database_gb": "Average Database in GB"},
                                           title="Top 10  Databases by Size")
        st.write(top_10_databases_by_size1)

    with col1:
        # top 10 tables by size
        top_10_tables_by_size = pd.read_sql(f"""select distinct TABLE_NAME , sum(BYTES/1000000000) as TOTAL_BYTES_GB from "SNOWFLAKE"."ACCOUNT_USAGE"."TABLES" 
                where deleted is null
                group by TABLE_NAME
                ORDER BY TOTAL_BYTES_GB  DESC
                LIMIT 10;""", connection)

        top_10_tables_by_size1 = px.bar(x=top_10_tables_by_size['table_name'],
                                        y=top_10_tables_by_size['total_bytes_gb'], width=700, height=370,
                                        labels={"x": "Table Name", "y": "Total Bytes in GB"},
                                        title="Top 10 Tables by Size",color_discrete_sequence=['#00CC96'])
        st.write(top_10_tables_by_size1)


    
        with col2:
                        
        # internal stages with storage in mb
            internal_stages= pd.read_sql("""select a.stage_name, date(a.created) , b.USAGE_DATE,round(b.AVERAGE_STAGE_BYTES/1000000,2) as AVERAGE_STAGE_BYTES_in_MB
            from SNOWFLAKE.ACCOUNT_USAGE.STAGES a
            join "SNOWFLAKE"."ACCOUNT_USAGE"."STAGE_STORAGE_USAGE_HISTORY" b
            on date(a.created)=b.USAGE_DATE
            where deleted is null and a.STAGE_TYPE= 'Internal Named'
            order by a.created desc limit 10""",connection)


            if internal_stages.empty:
                        pass
            else:
                internal_stages= pd.read_sql("""select a.stage_name, date(a.created) , b.USAGE_DATE,round(b.AVERAGE_STAGE_BYTES/1000000,2) as AVERAGE_STAGE_BYTES_in_MB
                from SNOWFLAKE.ACCOUNT_USAGE.STAGES a
                join "SNOWFLAKE"."ACCOUNT_USAGE"."STAGE_STORAGE_USAGE_HISTORY" b
                on date(a.created)=b.USAGE_DATE
                where deleted is null and a.STAGE_TYPE= 'Internal Named'
                order by a.created desc limit 10""",connection) 
                internal_stages1=px.line( x=internal_stages['stage_name'], y=internal_stages['average_stage_bytes_in_mb'],width=700, height=370,labels={"x":"Stage Name","y":"Average Stage Bytes in MB"},
                                                title ="Top 10 Internal Stages by Size")
                st.write(internal_stages1) 

    with col1:
    # Total Credits per Pipe Top

        total_credit = pd.read_sql(
            f"""select distinct PIPE_NAME,sum(CREDITS_USED) as total_credits_per_pipe, RANK()over(order by total_credits_per_pipe desc) as rank 
            from SNOWFLAKE.ACCOUNT_USAGE.PIPE_USAGE_HISTORY  group by PIPE_NAME order by RANK limit 5;""", connection)


        # with chart_container(total_credit):
        fig_4 = px.bar(total_credit, y="total_credits_per_pipe", x="pipe_name",width=700, height=370,
                           title='Top 5 Pipes Based on Credits Consumed',labels={"total_credits_per_pipe":"Total Credits Per Pipe","pipe_name":"Pipe Name"})
        st.write(fig_4)

    with col2:
        # Total Credits per Pipe for Last 7 Days

        credits_pipe_7 = pd.read_sql("""select distinct PIPE_NAME,TO_DATE(END_TIME) as date,CREDITS_USED from SNOWFLAKE.ACCOUNT_USAGE.PIPE_USAGE_HISTORY
        WHERE date >= DATEADD(day, -15, CURRENT_DATE()) order by DATE desc;
        """, connection)

        # with chart_container(credits_pipe_7):
        fig_5 = px.bar(credits_pipe_7, x="date", y="credits_used", color='pipe_name',width=700, height=370,
                           title='Total Credits per Pipe Since 15 Days',labels={"date":"Date","credits_used":"Credits Used"})
        fig_5.update_layout(showlegend=False)
        st.write(fig_5)
# //////////////////////////////////////////////////////////////
    with col1:
        large_tables = pd.read_sql(f"""select table_name as "Table Name",ROW_COUNT as "Row Count",BYTES/1000000000 as "GB",DATEDIFF(day,date(CREATED),current_timestamp) as since_CREATED_days,
                           DATEDIFF(day,date(LAST_ALTERED),current_timestamp) as "Last Used"
                           from SNOWFLAKE.ACCOUNT_USAGE.TABLES  where deleted is null  order by ROW_COUNT desc limit 10;""",
                                   connection)

        fig_7 = px.bar(large_tables, x="Table Name", y="gb", title="Top 10 Unused Tables", width=700,
                       height=370,
                       labels={
                           "gb": "Stored in GB",

                       },
                       hover_name="Table Name", hover_data=['gb', 'Row Count', 'Last Used'])
        fig_7.update_layout(xaxis={"categoryorder": "total descending"})
        st.write(fig_7)
        # ////////////////////////////////////////////

    with col2:
        # cloned tables with age and last used
        cloned = pd.read_sql(f"""with clone_1 as (
                select a.table_name as "Base Table",b.table_name as "Clone Table",b.TABLE_CREATED as TABLE_CREATED_b ,*
                from "SNOWFLAKE"."ACCOUNT_USAGE"."TABLE_STORAGE_METRICS" a
                ,SNOWFLAKE.ACCOUNT_USAGE.TABLE_STORAGE_METRICS b,
                SNOWFLAKE.ACCOUNT_USAGE.TABLES c where
                a."ID"=b."CLONE_GROUP_ID" and a.table_name <> b.table_name
                and b."TABLE_NAME"=c.TABLE_NAME and c.DELETED is null
                )
                select "Base Table", "Clone Table"
                ,datediff(day,date(TABLE_CREATED_b),current_date) as "Since Created",
                datediff(day,date(LAST_ALTERED),current_date) as "Last Used"
                from clone_1 order by "Since Created" desc limit 10 """, connection)

        cloned_fig = px.bar(cloned, x='Clone Table',
                            y='Last Used', width=700, height=370,
                            title='Top 10 Unused Cloned Tables', labels={"x": "Clone Table", "y": "Last Used"},
                            hover_data=['Base Table', 'Since Created'])
        cloned_fig.update_layout(showlegend=False, xaxis={"categoryorder": "total descending"})
        st.write(cloned_fig)

    # //////////////////////////////////////////////

    with col2:
        short = pd.read_sql(f"""select TABLE_NAME,ROW_COUNT,(BYTES/1000000)as MB,datediff(day,date(CREATED),date(DELETED)) as Table_deleted_days
        from SNOWFLAKE.ACCOUNT_USAGE.TABLES
        where datediff(day,date(CREATED),date(DELETED))=1 and deleted is not null
        and table_type='BASE TABLE' and IS_TRANSIENT='NO' and date(created)>='2023-03-01' and date(created)<'2023-03-15' order by MB desc;
        """, connection)
        short = px.bar(short, x='table_name', y='mb', width=700, height=370,
                       labels={"table_name": "Table Name", "mb": "Table Size in MB"}, hover_name="table_name",
                       hover_data=["mb", "table_deleted_days"],
                       title="Short Lived Tables")
        st.write(short)

    with col1:
        schema_last_use = pd.read_sql("""
        select a.table_schema,datediff(day,(date(b.SCHEMA_CREATED)),current_date) as "Since Created",datediff(day,max(date(a.last_altered)),current_date) as "last used"
        from SNOWFLAKE.ACCOUNT_USAGE.TABLES a left join
        SNOWFLAKE.ACCOUNT_USAGE.TABLE_STORAGE_METRICS b
        on b.TABLE_SCHEMA=a.TABLE_SCHEMA
        where a.DELETED is null and b.DELETED='FALSE' group by a.table_schema,b.SCHEMA_CREATED order by "last used" desc limit 10;
        """, connection)

        fig = px.bar(schema_last_use, y='last used', x='table_schema', title="Top 10 Idle Schemas", width=700,
                     height=370, labels={"table_schema": "Schema", "last used": "Last Used"},
                     hover_name='table_schema', hover_data=['last used', 'Since Created'])
        fig.update_layout(xaxis={"categoryorder": "total descending"})
        st.write(fig)

    with col1:
        # Bytes Transfered per Day

        byte_tra = pd.read_sql(
            f"""select distinct PIPE_NAME,TO_DATE(END_TIME) as date,BYTES_INSERTED,FILES_INSERTED as files_transfered from SNOWFLAKE.ACCOUNT_USAGE.PIPE_USAGE_HISTORY 
                  where start_time >=DATEADD(day, -120, CURRENT_DATE()) order by DATE desc;""", connection)

        # with chart_container(byte_tra):
        fig = px.bar(byte_tra, x="date", y=byte_tra["bytes_inserted"] / 1000000000, color='pipe_name', width=700,
                         height=370,
                         title='Gigabytes Transfered Through Pipe Since 120 Days', hover_name="pipe_name",
                         hover_data=['files_transfered'],
                         labels={"date": "Date", "bytes_inserted": "Gigabytes Inserted"})

        fig.update_layout(showlegend=False)
        st.write(fig)



# @st.cache_data
def Warehouse():
    # distinct warehouses

    # warehouse credits consumed per day
    large_tables = pd.read_sql(f"""
        select  sum (CREDITS_USED) as total_credits, sum(CREDITS_USED_COMPUTE) as compute_credits, 
        sum(CREDITS_USED_CLOUD_SERVICES) as cloud_credits from "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY" ;""",
                               connection)
    total_no_of_warehouses = pd.read_sql("""select count (WAREHOUSE_NAME) as WAREHOUSES from   
        (SELECT distinct WAREHOUSE_NAME from "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY")""", connection)

    col1,col2,col3=st.columns(3)
    col1.metric(label="Total No Of Warehouses", value=total_no_of_warehouses['warehouses'])
    col2.metric(label="Total Compute Credits", value=round(large_tables['compute_credits'][0], 2))
    col3.metric(label="Total Cloud Credits", value=round(large_tables['cloud_credits'][0], 2))

    style_metric_cards()

    st.write("**Warehouse Statistics**")
    wh_test = pd.read_sql("""show warehouses""", connection)

    df = pd.DataFrame(wh_test,
                      columns=['name', 'size', 'min_cluster_count', 'max_cluster_count', 'auto_suspend', 'auto_resume',
                               'resource_monitor'])

    df['auto_suspend'] = df['auto_suspend'].fillna(0)

    # df['auto_suspend'] = df['auto_suspend']

    def color_survived(val):
        color = None

        if val > 0:
            color = 'background-color:#d2f8d2 '  # green d2f8d2
        if val >= 180:
            color = 'background-color:#fff0ac'  # yellow fff0ac
        if val >= 300:
            color = 'background-color:#ffd6ac'  # orange ffd6ac
        if val > 540:
            color = 'background-color:#ffc4c4'  # red ffc4c4
        if val == 0:
            color = 'background-color:#ffc4c4'  # red ffc4c4

        return (color)

    def color_survived_1(val):
        color = None
        if val == "true":
            color = 'background-color:#d2f8d2'
        else:
            color = 'background-color:#ffc4c4'
        return (color)

    def color_survived_2(val):
        color = None
        if val == "null":
            color = 'background-color:#ffc4c4'
        else:
            color = 'background-color:#d2f8d2'
        return (color)






    df1 = pd.read_sql("""
    with Query_History as (
    SELECT warehouse_name,WAREHOUSE_SIZE,min(cluster_number) as min_cluster,max(cluster_number) as max_cluster ,count(BYTES_WRITTEN_TO_RESULT/1000000000) as total,
    round(sum(execution_time/60000),2) total_execution,count(QUERY_ID) as total_queries,
    sum(CASE WHEN (BYTES_WRITTEN_TO_RESULT/1000000000) > 1 THEN round(execution_time/60000,2)  END) AS large_query_execution,
    count(CASE WHEN (BYTES_WRITTEN_TO_RESULT/1000000000) > 1 THEN (BYTES_WRITTEN_TO_RESULT/1000000000)  END) AS greater,
    count(CASE WHEN (BYTES_WRITTEN_TO_RESULT/1000000000) < 1 THEN (BYTES_WRITTEN_TO_RESULT/1000000000)  END) AS lower
    FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
    where CLUSTER_NUMBER is not null 
    group by warehouse_name,WAREHOUSE_SIZE
    ),
    QH AS
    (SELECT  DATE(START_TIME) AS SS1,WAREHOUSE_NAME,WAREHOUSE_SIZE FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
    WHERE WAREHOUSE_SIZE IS NOT NULL 
    GROUP BY SS1,WAREHOUSE_NAME,WAREHOUSE_SIZE),
    WMH AS
    (
    SELECT DATE(START_TIME) AS SS,WAREHOUSE_NAME,sum(CREDITS_USED) as CREDITS_USED FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY
    GROUP BY SS,WAREHOUSE_NAME,CREDITS_USED),
    warehouse_metering as
    (SELECT a.warehouse_name,a.warehouse_size,sum(b.credits_used) as credits_used from qh a join
    wmh b
    on a.warehouse_name=b.warehouse_name
    and ss=ss1
    group by a.warehouse_name,a.warehouse_size)

    select a.warehouse_name,a.WAREHOUSE_SIZE,min(a.min_cluster)as min_cluster,max(a.max_cluster) as max_cluster,nvl(sum(a.greater),0) as large_queries,nvl(sum(a.lower),0) as small_queries,
    a.total_queries,large_queries/total*100 as Large_queries_percentage,small_queries/a.total*100 as small_queries_percentage,
    nvl(a.large_query_execution/LARGE_QUERIES,0) as large_query_avg_execution,(a.total_execution/TOTAL_QUERIES) as Total_query_avg_execution,b.credits_used
    from Query_History a join
    warehouse_metering b
    on a.WAREHOUSE_NAME=b.WAREHOUSE_NAME
    and a.WAREHOUSE_SIZE=b.WAREHOUSE_SIZE
    where a.WAREHOUSE_SIZE is not null 
    group by a.warehouse_name,a.WAREHOUSE_SIZE,a.total,a.large_query_execution,a.total_execution,a.total_queries,b.credits_used
    order by b.credits_used desc ;   
    """, connection)

    df2 = pd.read_sql("""
    show warehouses;
    """, connection)
   
    df2.rename(columns = {'name':'warehouse_name'}, inplace = True)
 

    # df3 = pd.concat([df1, df2.iloc[:, [11,12,24]]], axis=1, join='inner')
    df3 = pd.merge(df1, df2, on='warehouse_name', how='left')
    
    df3=df3.iloc[:, [0, 1, 2, 3, 22,23,35, 4, 5, 6, 7, 8, 9, 10, 11]]


    st.dataframe(df3.style.applymap(color_survived, subset=['auto_suspend'])
                 .applymap(color_survived_1, subset=['auto_resume'])
                 .applymap(color_survived_2, subset=['resource_monitor']),use_container_width=True)
    # distinct warehouses
    # with st.sidebar:
    count_wh = pd.read_sql(
        """ SELECT DISTINCT WAREHOUSE_NAME as count_wh FROM "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_EVENTS_HISTORY" """,connection)

    wh = selectbox("select warehouse", count_wh, no_selection_label="Overall Warehouses")

        # result = date_range_picker("Select a date range")

    warehouse_credits_consumed_per_day = pd.read_sql(f"""select distinct WAREHOUSE_NAME,TO_DATE(END_TIME) as date, sum(CREDITS_USED) as "total credits"
                          from "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY" where DATE >=DATEADD(day, -89, CURRENT_DATE())
                          group by WAREHOUSE_NAME,date,CREDITS_USED order by date desc;""", connection)

    fig_11 = px.bar(warehouse_credits_consumed_per_day, x='date',
                   y='warehouse_name',color="warehouse_name",width=1500, height=370,
                   hover_name="warehouse_name",hover_data=["date","total credits"],
                    labels={"date": "Date","warehouse_name": "Warehouse Name",},title="Warehouse Credits Consumed Since 90 Days")
    st.write(fig_11)

    col1, col2 = st.columns(2)


    if wh == None:

        with col1:
            # warehouse age
            warehouse_age  = pd.read_sql(f"""select a.WAREHOUSE_NAME, (DATEDIFF(day,min(date(a.START_TIME)),current_date)) as age,nvl(cast((DATEDIFF(day,max(date(a.START_TIME)),current_date))as varchar),'never used') as Last_Used
            from SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY a
            left join"SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_EVENTS_HISTORY" b 
            on a.WAREHOUSE_NAME= b.WAREHOUSE_NAME  
            group by a.WAREHOUSE_NAME order by AGE desc limit 10""",connection)
            # st.write(warehouse_age)
            warehouse_age1 =px.bar(warehouse_age,x='warehouse_name',
                y='age',width=700, height=370,labels={"x":"Warehouse Names","y":"Ages","age":"age in days","last_used":"last used in days"},
                title ="Top 10 Warehouses with Respect to Age ", hover_data=['last_used'])

            st .write(warehouse_age1)
            # date selection
        with col2:
            #   Total Warehouse Credits
            CREDITS_USED_COMPUTE = pd.read_sql(
                        f"""select distinct WAREHOUSE_NAME,sum(CREDITS_USED_COMPUTE)as COMPUTE_CREDITS,sum(CREDITS_USED_CLOUD_SERVICES)as CLOUD_CREDITS from "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY"
                        where END_TIME >=DATEADD(day, -29, CURRENT_DATE()) group by WAREHOUSE_NAME order by COMPUTE_CREDITS desc limit 10; """, connection)
            fig = px.bar(CREDITS_USED_COMPUTE, x="warehouse_name", y=["cloud_credits","compute_credits"],width=700, height=370,
                         labels={
                             "warehouse_name": "Warehouse Name",
                             "cloud_credits": "Cloud Credits",
                             "compute_credits": "Compute Credits"
                         },
            title="Top 10 Warehouse Credits Since 30 Days")
            fig.update_layout(showlegend=False)
            st.write(fig)

        with col1:
            # Top 10 Executed Queries Count
            count_wh = pd.read_sql(f"""  select distinct QUERY_TYPE,QUERY_TEXT,WAREHOUSE_NAME, count(QUERY_TEXT) as count,dense_rank() over(order by count desc )as rank 
                from "SNOWFLAKE"."ACCOUNT_USAGE"."QUERY_HISTORY"  where END_TIME >=DATEADD(day, -15, CURRENT_DATE())
                    group by QUERY_TYPE,QUERY_TEXT,WAREHOUSE_NAME order by RANK limit 10""", connection)

            fig_11 = px.bar(count_wh, x="warehouse_name", y="count", color='query_text',
                            title="Frequently Used Queries",
                            width=700, height=370,
                            labels={
                                "warehouse_name": "Warehouse Name",
                                "count": "Count"
                            },
                            hover_name="warehouse_name", hover_data=['count', 'query_text'])
            fig_11.update_layout(showlegend=False)
            st.write(fig_11)
        with col2:
            # Top 10 Queries Based on Most Time Consumed

            max_time_consumed = pd.read_sql(f""" select WAREHOUSE_NAME,QUERY_TEXT,round(TOTAL_ELAPSED_TIME/60000,0) as minutes_consumed_per_query
                from "SNOWFLAKE"."ACCOUNT_USAGE"."QUERY_HISTORY"  where END_TIME >=DATEADD(day, -15, CURRENT_DATE())
                order by minutes_Consumed_per_query desc limit 10""", connection)
            # Create chart

            fig_10 = px.bar(max_time_consumed, x="warehouse_name", y="minutes_consumed_per_query",
                            color='minutes_consumed_per_query', title="Expensive Queries",
                            width=700, height=370,
                            labels={
                                "warehouse_name": "Warehouse Name",
                                "minutes_consumed_per_query": "Minutes Consumed per Query"
                            },
                            hover_name="warehouse_name", hover_data=['minutes_consumed_per_query', 'query_text'])
            fig_10.update_layout(showlegend=False)
            st.write(fig_10)

        with col1:

            # Partner Tools Consuming Credits
            Partner_Tools = pd.read_sql("""
            WITH CLIENT_HOUR_EXECUTION_CTE AS (
                SELECT  CASE
                     WHEN CLIENT_APPLICATION_ID LIKE 'Go %' THEN 'Go'
                     WHEN CLIENT_APPLICATION_ID LIKE 'Snowflake UI %' THEN 'Snowflake UI'
                     WHEN CLIENT_APPLICATION_ID LIKE 'SnowSQL %' THEN 'SnowSQL'
                     WHEN CLIENT_APPLICATION_ID LIKE 'JDBC %' THEN 'JDBC'
                     WHEN CLIENT_APPLICATION_ID LIKE 'PythonConnector %' THEN 'Python'
                     WHEN CLIENT_APPLICATION_ID LIKE 'ODBC %' THEN 'ODBC'
                     ELSE 'NOT YET MAPPED: ' || CLIENT_APPLICATION_ID
                   END AS CLIENT_APPLICATION_NAME
                ,WAREHOUSE_NAME
                ,DATE_TRUNC('hour',START_TIME) as START_TIME_HOUR
                ,SUM(EXECUTION_TIME)  as CLIENT_HOUR_EXECUTION_TIME
                FROM "SNOWFLAKE"."ACCOUNT_USAGE"."QUERY_HISTORY" QH
                JOIN "SNOWFLAKE"."ACCOUNT_USAGE"."SESSIONS" SE ON SE.SESSION_ID = QH.SESSION_ID
                WHERE WAREHOUSE_NAME IS NOT NULL
                AND EXECUTION_TIME > 0

             --Change the below filter if you want to look at a longer range than the last 1 month
                AND START_TIME > DATEADD(Month,-1,CURRENT_TIMESTAMP())
                group by 1,2,3
                )
            , HOUR_EXECUTION_CTE AS (
                SELECT  START_TIME_HOUR
                ,WAREHOUSE_NAME
                ,SUM(CLIENT_HOUR_EXECUTION_TIME) AS HOUR_EXECUTION_TIME
                FROM CLIENT_HOUR_EXECUTION_CTE
                group by 1,2
            )
            , APPROXIMATE_CREDITS AS (
                SELECT
                A.CLIENT_APPLICATION_NAME
                ,C.WAREHOUSE_NAME
                ,(A.CLIENT_HOUR_EXECUTION_TIME/B.HOUR_EXECUTION_TIME)*C.CREDITS_USED AS APPROXIMATE_CREDITS_USED

                FROM CLIENT_HOUR_EXECUTION_CTE A
                JOIN HOUR_EXECUTION_CTE B  ON A.START_TIME_HOUR = B.START_TIME_HOUR and B.WAREHOUSE_NAME = A.WAREHOUSE_NAME
                JOIN "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY" C ON C.WAREHOUSE_NAME = A.WAREHOUSE_NAME AND C.START_TIME = A.START_TIME_HOUR
            )

            SELECT
             CLIENT_APPLICATION_NAME
            ,WAREHOUSE_NAME
            ,SUM(APPROXIMATE_CREDITS_USED) AS APPROXIMATE_CREDITS_USED
            FROM APPROXIMATE_CREDITS
            GROUP BY 1,2
            ORDER BY 3 DESC
            ;

            """, connection)

            fig = px.bar(Partner_Tools, x='warehouse_name', y='approximate_credits_used', width=700, height=370,
                         color='client_application_name',
                         labels={"warehouse_name": "Warehouse Name",
                                 "approximate_credits_used": "Approximate Credits Used"},
                         hover_name="client_application_name", hover_data=["approximate_credits_used"],
                         title="Partner Tools Credit Consumption")
            fig.update_layout(showlegend=False)
            st.write(fig)

        with col2:

            # Most Expensive Queries
            expensive_queries = pd.read_sql("""
            WITH WAREHOUSE_SIZE AS
            (
                 SELECT WAREHOUSE_SIZE, NODES
                   FROM (
                          SELECT 'X-SMALL' AS WAREHOUSE_SIZE, 1 AS NODES
                          UNION ALL
                          SELECT 'SMALL' AS WAREHOUSE_SIZE, 2 AS NODES
                          UNION ALL
                          SELECT 'MEDIUM' AS WAREHOUSE_SIZE, 4 AS NODES
                          UNION ALL
                          SELECT 'LARGE' AS WAREHOUSE_SIZE, 8 AS NODES
                          UNION ALL
                          SELECT 'X-LARGE' AS WAREHOUSE_SIZE, 16 AS NODES
                          UNION ALL
                          SELECT '2X-LARGE' AS WAREHOUSE_SIZE, 32 AS NODES
                          UNION ALL
                          SELECT '3X-LARGE' AS WAREHOUSE_SIZE, 64 AS NODES
                          UNION ALL
                          SELECT '4X-LARGE' AS WAREHOUSE_SIZE, 128 AS NODES
                        )
            ),
            QUERY_HISTORY AS
            (
                 SELECT QH.QUERY_ID
                       ,QH.QUERY_TEXT
                       ,QH.USER_NAME
                       ,QH.ROLE_NAME
                       ,QH.EXECUTION_TIME
                       ,QH.WAREHOUSE_SIZE
                  FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY QH
                 WHERE START_TIME > DATEADD(month,-2,CURRENT_TIMESTAMP())
            )

            SELECT QH.QUERY_ID
                  ,'https://' || current_account() || '.snowflakecomputing.com/console#/monitoring/queries/detail?queryId='||QH.QUERY_ID AS QU
                  ,QH.QUERY_TEXT
                  ,QH.USER_NAME
                  ,QH.ROLE_NAME
                  ,QH.EXECUTION_TIME as EXECUTION_TIME_MILLISECONDS
                  ,(QH.EXECUTION_TIME/(1000)) as EXECUTION_TIME_SECONDS
                  ,(QH.EXECUTION_TIME/(1000*60)) AS EXECUTION_TIME_MINUTES
                  ,(QH.EXECUTION_TIME/(1000*60*60)) AS EXECUTION_TIME_HOURS
                  ,WS.WAREHOUSE_SIZE
                  ,WS.NODES
                  ,(QH.EXECUTION_TIME/(1000*60*60))*WS.NODES as RELATIVE_PERFORMANCE_COST

            FROM QUERY_HISTORY QH
            JOIN WAREHOUSE_SIZE WS ON WS.WAREHOUSE_SIZE = upper(QH.WAREHOUSE_SIZE)
            ORDER BY RELATIVE_PERFORMANCE_COST DESC
            LIMIT 200
            ;
            """, connection)

            fig = px.bar(expensive_queries, x='user_name', y='execution_time_minutes', width=700, height=370,
                         color='query_text',
                         labels={"user_name": "User Name", "execution_time_minutes": "Execution Time Minutes"},
                         hover_name="role_name", hover_data=['warehouse_size', 'nodes', 'relative_performance_cost'],
                         title="Most Expensive Queries")
            fig.update_layout(showlegend=False)
            st.write(fig)

        with col1:

            # Materialized Views Cost History (by Day by Object)(Top 10 materialized view cost from last month to current date)

            Materialized = pd.read_sql("""
            SELECT

            TO_DATE(START_TIME) as DATE
            ,DATABASE_NAME
            ,SCHEMA_NAME
            ,TABLE_NAME
            ,SUM(CREDITS_USED) as CREDITS_USED

            FROM "SNOWFLAKE"."ACCOUNT_USAGE"."MATERIALIZED_VIEW_REFRESH_HISTORY"

            WHERE START_TIME >= dateadd(month,-1,current_timestamp())
            GROUP BY 1,2,3,4
            ORDER BY 5 DESC limit 10


            """, connection)

            fig = px.bar(Materialized, x='table_name', y='credits_used', width=700, height=370,
                         labels={"table_name ": "Table Name", "credits_used": "Credits Used"}, color='schema_name',
                         hover_name="schema_name",
                         title='Top 10 Materialized Views Cost Since 30 Days')
            fig.update_layout(showlegend=False, xaxis={"categoryorder": "total descending"})
            st.write(fig)


    else:
        with col1:
                # warehouse age
            warehouse_age  = pd.read_sql(f"""select a.WAREHOUSE_NAME, (DATEDIFF(day,min(date(a.START_TIME)),current_date)) as age,nvl(cast((DATEDIFF(day,max(date(a.START_TIME)),current_date))as varchar),'never used') as Last_Used
            from SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY a
            left join"SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_EVENTS_HISTORY" b 
            on a.WAREHOUSE_NAME= b.WAREHOUSE_NAME  
            where a.WAREHOUSE_NAME='{wh}'
            group by a.WAREHOUSE_NAME order by AGE desc limit 10
            
                """,connection)

            warehouse_age1 =px.bar( warehouse_age,x='warehouse_name',
                y='age',width=700, height=370,labels={"x":"Warehouse Names","y":"Warehouse Age","age":"age in days","last_used":"last used in days"},
                title ="Top 10 Warehouse with Respect to Age", hover_data=['last_used'])
            warehouse_age1.update_layout(showlegend=False)
            st .write(warehouse_age1)
        with col2:
               #   Total Warehouse Credits
            CREDITS_USED_COMPUTE = pd.read_sql(
                        f"""select distinct WAREHOUSE_NAME,sum(CREDITS_USED_COMPUTE)as COMPUTE_CREDITS,sum(CREDITS_USED_CLOUD_SERVICES)as CLOUD_CREDITS from "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY"
                              where END_TIME >=DATEADD(day, -29, CURRENT_DATE()) and WAREHOUSE_NAME='{wh}' group by WAREHOUSE_NAME order by COMPUTE_CREDITS desc; """,
                        connection)
            fig = px.bar(CREDITS_USED_COMPUTE, x="warehouse_name", y=["cloud_credits", "compute_credits"],width=700, height=370,
                         labels={
                             "warehouse_name": "Warehouse Name",
                             "cloud_credits": "Cloud Credits",
                             "compute_credits": "Compute Credits"
                         },
                                 title=f"Total '{wh}' Warehouse Credits Since 30 Days")
            fig.update_layout(showlegend=False)
            st.write(fig)

        with col1:
                   # Top 10 Executed Queries Count
            count_wh = pd.read_sql(f"""  select distinct QUERY_TYPE,QUERY_TEXT,WAREHOUSE_NAME, count(QUERY_TEXT) as count,dense_rank() over(order by count desc )as rank 
                       from "SNOWFLAKE"."ACCOUNT_USAGE"."QUERY_HISTORY"  where END_TIME >=DATEADD(day, -15, CURRENT_DATE()) and WAREHOUSE_NAME='{wh}'
                           group by QUERY_TYPE,QUERY_TEXT,WAREHOUSE_NAME order by RANK limit 10""", connection)

            fig_11 = px.bar(count_wh, x="warehouse_name", y="count", color='query_text',
                                   title="Frequently Used Queries",
                                   width=700, height=370,
                                   labels={
                                       "warehouse_name": "Warehouse Name",
                                       "count": "Count"
                                   },
                                   hover_name="warehouse_name", hover_data=['count', 'query_text'])
            fig_11.update_layout(showlegend=False)
            st.write(fig_11)

        with col2:
                   # Top 10 Queries Based on Most Time Consumed

            max_time_consumed = pd.read_sql(f""" select WAREHOUSE_NAME,QUERY_TEXT,round(TOTAL_ELAPSED_TIME/60000,0) as minutes_consumed_per_query
                    from "SNOWFLAKE"."ACCOUNT_USAGE"."QUERY_HISTORY"  where END_TIME >=DATEADD(day, -15, CURRENT_DATE()) and WAREHOUSE_NAME='{wh}'
                    order by minutes_Consumed_per_query desc limit 10""", connection)
                   # Create chart

            fig_10 = px.bar(max_time_consumed, x="warehouse_name", y="minutes_consumed_per_query",
                                   color='minutes_consumed_per_query', title="Expensive Queries",
                                   width=700, height=370,
                                   labels={
                                       "warehouse_name": "Warehouse Name",
                                       "minutes_consumed_per_query": "Minutes Consumed per Query"
                                   },
                                   hover_name="warehouse_name", hover_data=['minutes_consumed_per_query', 'query_text'])
            fig_10.update_layout(showlegend=False)
            st.write(fig_10)
        with col1:

            # Partner Tools Consuming Credits
            Partner_Tools = pd.read_sql(f"""
            WITH CLIENT_HOUR_EXECUTION_CTE AS (
                SELECT  CASE
                     WHEN CLIENT_APPLICATION_ID LIKE 'Go %' THEN 'Go'
                     WHEN CLIENT_APPLICATION_ID LIKE 'Snowflake UI %' THEN 'Snowflake UI'
                     WHEN CLIENT_APPLICATION_ID LIKE 'SnowSQL %' THEN 'SnowSQL'
                     WHEN CLIENT_APPLICATION_ID LIKE 'JDBC %' THEN 'JDBC'
                     WHEN CLIENT_APPLICATION_ID LIKE 'PythonConnector %' THEN 'Python'
                     WHEN CLIENT_APPLICATION_ID LIKE 'ODBC %' THEN 'ODBC'
                     ELSE 'NOT YET MAPPED: ' || CLIENT_APPLICATION_ID
                   END AS CLIENT_APPLICATION_NAME
                ,WAREHOUSE_NAME
                ,DATE_TRUNC('hour',START_TIME) as START_TIME_HOUR
                ,SUM(EXECUTION_TIME)  as CLIENT_HOUR_EXECUTION_TIME
                FROM "SNOWFLAKE"."ACCOUNT_USAGE"."QUERY_HISTORY" QH
                JOIN "SNOWFLAKE"."ACCOUNT_USAGE"."SESSIONS" SE ON SE.SESSION_ID = QH.SESSION_ID
                WHERE WAREHOUSE_NAME IS NOT NULL and WAREHOUSE_NAME='{wh}'
                AND EXECUTION_TIME > 0

             --Change the below filter if you want to look at a longer range than the last 1 month
                AND START_TIME > DATEADD(Month,-1,CURRENT_TIMESTAMP())
                group by 1,2,3
                )
            , HOUR_EXECUTION_CTE AS (
                SELECT  START_TIME_HOUR
                ,WAREHOUSE_NAME
                ,SUM(CLIENT_HOUR_EXECUTION_TIME) AS HOUR_EXECUTION_TIME
                FROM CLIENT_HOUR_EXECUTION_CTE
                group by 1,2
            )
            , APPROXIMATE_CREDITS AS (
                SELECT
                A.CLIENT_APPLICATION_NAME
                ,C.WAREHOUSE_NAME
                ,(A.CLIENT_HOUR_EXECUTION_TIME/B.HOUR_EXECUTION_TIME)*C.CREDITS_USED AS APPROXIMATE_CREDITS_USED

                FROM CLIENT_HOUR_EXECUTION_CTE A
                JOIN HOUR_EXECUTION_CTE B  ON A.START_TIME_HOUR = B.START_TIME_HOUR and B.WAREHOUSE_NAME = A.WAREHOUSE_NAME
                JOIN "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY" C ON C.WAREHOUSE_NAME = A.WAREHOUSE_NAME AND C.START_TIME = A.START_TIME_HOUR
            )

            SELECT
             CLIENT_APPLICATION_NAME
            ,WAREHOUSE_NAME
            ,SUM(APPROXIMATE_CREDITS_USED) AS APPROXIMATE_CREDITS_USED
            FROM APPROXIMATE_CREDITS
            GROUP BY 1,2
            ORDER BY 3 DESC
            ;

            """, connection)

            fig = px.bar(Partner_Tools, x='warehouse_name', y='approximate_credits_used', width=700, height=370,
                         color='client_application_name',
                         labels={"warehouse_name": "Warehouse Name",
                                 "approximate_credits_used": "Approximate Credits Used"},
                         hover_name="client_application_name", hover_data=["approximate_credits_used"],
                         title="Partner Tools Credit Consumption")
            fig.update_layout(showlegend=False)
            st.write(fig)




@st.cache_data
def Miscellaneous():
    # Total no of duplicate function
    duplicate_function = pd.read_sql(""" select nvl(sum(function_duplicate_count),0) as total_duplicate_functions from
               (SELECT FUNCTION_NAME,FUNCTION_LANGUAGE, COUNT(FUNCTION_NAME) as function_duplicate_count
               FROM "SNOWFLAKE"."ACCOUNT_USAGE"."FUNCTIONS" where deleted is null
               GROUP BY FUNCTION_LANGUAGE,FUNCTION_NAME
               HAVING function_duplicate_count>1
               ORDER BY function_duplicate_count DESC)sub""", connection)

    # function_count
    function_count = pd.read_sql(
        """ select count(FUNCTION_NAME) as Total_function from "SNOWFLAKE"."ACCOUNT_USAGE"."FUNCTIONS" where deleted is null""",
        connection)

    col1,col2=st.columns(2)
    col2.metric(label="PROBABLE DUPLICATE FUNCTIONS", value=duplicate_function['total_duplicate_functions'])
    col1.metric(label="TOTAL FUNCTIONS", value=function_count['total_function'])
    style_metric_cards()
    # //////////////////////////////////////////////
    # Total no of function with respect to languages
    # function_languages = pd.read_sql(""" SELECT FUNCTION_LANGUAGE, COUNT(*) as Total_no_functions
    #     FROM "SNOWFLAKE"."ACCOUNT_USAGE"."FUNCTIONS" where deleted is null
    #     GROUP BY FUNCTION_LANGUAGE """, connection)
    #
    # function_languages1 = px.bar(x=function_languages['function_language'], y=function_languages['total_no_functions'],
    #                              width=570, height=400, labels={"x": "function_language", "y": "total_no_functions"},
    #                              title="FUNCTION LANGUAGES")
    # stcol1.write(function_languages1)
# /////////////////////////////////////////////////////
    col1,col2=st.columns(2)
    with col1:
        # For store_procedure
        store_procedure = pd.read_sql(""" SELECT f.FUNCTION_NAME,f.function_schema,f.ARGUMENT_SIGNATURE,qh.query_type,qh.query_text,count(f.FUNCTION_NAME) as Total_no_execute
            FROM "SNOWFLAKE"."ACCOUNT_USAGE"."QUERY_HISTORY" qh
            JOIN "SNOWFLAKE"."ACCOUNT_USAGE"."FUNCTIONS" f ON qh.SCHEMA_ID = f.FUNCTION_SCHEMA_ID  where query_type = 'CALL' 
            or  query_text like '%FUNCTION%' and query_type != 'CREATE' and QUERY_TEXT not like '%CREATE OR REPLACE%' and query_text like 'CALL' 
            and query_text like 'SElECT' and query_type not like '%WITH%' and deleted is null
            group by FUNCTION_NAME,query_type,query_text,function_schema,ARGUMENT_SIGNATURE,created
            order by Total_no_execute desc limit 25""", connection)

        fig_9 = px.bar(store_procedure, x="function_name", y="total_no_execute", color='function_name', title="Similar Executed Procedures", width=700,
                       height=370,
                       labels={
                           "function_name": "Function Name",
                           "total_no_execute": "Execute"
                       },
                       hover_name="function_name", hover_data=["total_no_execute", 'query_text', 'function_schema'])
        fig_9.update_layout(showlegend=False)
        fig_9.update_layout(xaxis={"categoryorder": "total descending"})
        st.write(fig_9)

    with col2:
        # For UDF
        udf = pd.read_sql(""" SELECT f.FUNCTION_NAME,f.function_schema,f.ARGUMENT_SIGNATURE,qh.query_type,qh.query_text,count(f.FUNCTION_NAME) as Total_no_execute
            FROM "SNOWFLAKE"."ACCOUNT_USAGE"."QUERY_HISTORY" qh
            JOIN "SNOWFLAKE"."ACCOUNT_USAGE"."FUNCTIONS" f ON qh.SCHEMA_ID = f.FUNCTION_SCHEMA_ID  where FUNCTION_DEFINITION is null and QUERY_TYPE = 'SELECT'
            and deleted is null and QUERY_TEXT != '%SELECT * FROM%'
            group by FUNCTION_NAME,query_type,query_text,function_schema,ARGUMENT_SIGNATURE
            order by Total_no_execute desc limit 25""", connection)

        fig_8 = px.bar(udf, x="function_name", y="total_no_execute",color= 'function_name' ,title="Similar Executed UDFs", width=700, height=370,
                           labels={
                               "function_name": "Function Name",
                               "total_no_execute": "Execute"
                           },
                           hover_name="function_name", hover_data=["total_no_execute", 'query_text', 'function_schema'])
        fig_8.update_layout(showlegend=False)
        fig_8.update_layout(xaxis={"categoryorder": "total descending"})
        st.write(fig_8)





    # /////////////////////////////////////////////////////////
    with col2:
        failed_login=pd.read_sql(f"""select TO_DATE(EVENT_TIMESTAMP) as date,to_time(EVENT_TIMESTAMP)as time,USER_NAME,EVENT_TYPE,REPORTED_CLIENT_TYPE,IS_SUCCESS ,
                               ERROR_MESSAGE as "Error Message",CLIENT_IP as "IP Adress"
                from "SNOWFLAKE"."ACCOUNT_USAGE"."LOGIN_HISTORY" where EVENT_TYPE = 'LOGIN' and REPORTED_CLIENT_TYPE = 'SNOWFLAKE_UI'and IS_SUCCESS = 'NO' 
                and DATE >=DATEADD(day, -29, CURRENT_DATE())
                order by DATE desc ;""",connection)



        fig_6 = px.scatter(failed_login, x='date', y="time",title="Failed Logins of Snowflake UI Since 30 Days",width=700,height=370,
                           labels={
                               "date": "Date",
                               "time": "Time"
                           },
                           hover_name="user_name", hover_data=["IP Adress", "Error Message"])
        st.write(fig_6)

    with col1:
        fail_logins_per_day = pd.read_sql(f"""select REPORTED_CLIENT_TYPE,USER_NAME,date(EVENT_TIMESTAMP) as date,count(IS_SUCCESS) as total_fail_login from SNOWFLAKE.ACCOUNT_USAGE.LOGIN_HISTORY 
                where IS_SUCCESS ='NO' and date>=DATEADD(day, -29, CURRENT_DATE()) 
                group by date,USER_NAME,REPORTED_CLIENT_TYPE
                order by total_fail_login desc;""", connection)

        fail_logins_per_day1 = px.bar(fail_logins_per_day, x='date',
                                      y='total_fail_login', width=700, height=370, color="reported_client_type",
                                      labels={"date": "Date", "total_fail_login": "TOTAL FAIL LOGINS"}, hover_name="user_name",
                                      title="Failed Logins Since 30 Days")
        st.write(fail_logins_per_day1)
# ///////////////////////////////////////////////////////
    with col1:
        # warehouse_performance_laging
        warehouse_performance_laging = pd.read_sql(""" 
                     select distinct q.USER_NAME as "User Name",q.QUERY_ID,w.WAREHOUSE_NAME,q.SCHEMA_NAME,q.START_TIME,q.END_TIME,q.WAREHOUSE_SIZE,
                     round((q.BYTES_SPILLED_TO_REMOTE_STORAGE/1073741824),3) as "DATA STORAGE in GB (remote)",
                     q.query_text from "SNOWFLAKE"."ACCOUNT_USAGE"."QUERY_HISTORY" q
                     join"SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY" w on q.WAREHOUSE_ID=w.WAREHOUSE_ID
                     where BYTES_SPILLED_TO_REMOTE_STORAGE>=1 order by "DATA STORAGE in GB (remote)" desc""",
                                                   connection)


        fig_7 = px.bar(warehouse_performance_laging, x="User Name", y="DATA STORAGE in GB (remote)", title="Top 10 Inefficient Queries", width=700, height=370,
                       color="query_text",
                       hover_name="User Name", hover_data=['DATA STORAGE in GB (remote)', 'query_text', 'warehouse_size'])
        fig_7.update_layout(showlegend=False)
        st.write(fig_7)


    with col2:
        # Top 10 failed task and total credits consumed
        cloned = pd.read_sql(f"""select t.NAME,t.SCHEMA_NAME,t.ERROR_MESSAGE,DATE(COMPLETED_TIME) as date,t.STATE,q.QUERY_TEXT,count(t.NAME) as Total_Execution,(w.CREDITS_USED) as total_credits
        from SNOWFLAKE.ACCOUNT_USAGE.TASK_HISTORY t
        join SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY q on q.QUERY_ID=t.QUERY_ID 
        join SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY w on q.WAREHOUSE_ID = w.WAREHOUSE_ID
        where STATE='FAILED' group by STATE,NAME,t.SCHEMA_NAME,q.QUERY_TEXT,total_credits,date,t.ERROR_MESSAGE order by Total_Execution desc limit 10""",
                             connection)

        cloned_fig = px.bar(cloned, x='name',
                            y='total_execution', width=700, height=370,
                            title='Top 10 Failed Tasks by Credit Consumption',
                            labels={"x": "Name", "y": "Total Execution"},
                            hover_data=['total_credits', 'query_text', 'date'])
        cloned_fig.update_layout(showlegend=False,xaxis={"categoryorder": "total descending"})
        st.write(cloned_fig)

    with col1:
        # Top 10 Load Failed through Snowpipe

        Top_10_Load_Failed_from_Snowpipe = pd.read_sql(f""" SELECT
TO_DATE(c.LAST_LOAD_TIME) as LOAD_DATE
    ,c.STATUS
    ,c.TABLE_CATALOG_NAME as DATABASE_NAME
    ,c.TABLE_SCHEMA_NAME as SCHEMA_NAME
    ,c.TABLE_NAME
    ,CASE WHEN c.PIPE_NAME IS NULL THEN 'COPY' ELSE 'SNOWPIPE' END AS INGEST_METHOD
    ,SUM(c.ROW_COUNT) as ROW_COUNT
    ,SUM(c.ROW_PARSED) as ROWS_PARSED
    ,AVG(c.FILE_SIZE) as AVG_FILE_SIZE_BYTES
    ,SUM(c.FILE_SIZE) as TOTAL_FILE_SIZE_BYTES
    ,SUM(c.FILE_SIZE)/POWER(1024,1) as TOTAL_FILE_SIZE_KB
    ,SUM(c.FILE_SIZE)/POWER(1024,2) as TOTAL_FILE_SIZE_MB
    ,SUM(c.FILE_SIZE)/POWER(1024,3) as TOTAL_FILE_SIZE_GB
,SUM(c.FILE_SIZE)/POWER(1024,4) as TOTAL_FILE_SIZE_TB
,(w.CREDITS_USED) as total_credits
FROM "SNOWFLAKE"."ACCOUNT_USAGE"."COPY_HISTORY" c
join SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY w
where STATUS ='Load failed' and INGEST_METHOD ='SNOWPIPE'
GROUP BY 1,2,3,4,5,6,CREDITS_USED
ORDER BY TOTAL_FILE_SIZE_GB desc limit 10""",connection)
            # Create chart

        fig_10 = px.bar(Top_10_Load_Failed_from_Snowpipe, x="table_name", y="total_file_size_gb",
                        color='total_file_size_gb', title="Top 10 Loads Failed through Snowpipe",
                        width=700, height=370,
                        labels={
                            "table_name": "Table Name",
                            "total_file_size_gb": "GB"
                        },
                        hover_name="table_name",
                        hover_data=['table_name', 'total_credits', 'schema_name', 'total_file_size_gb'])
        fig_10.update_layout(showlegend=False, xaxis={"categoryorder": "total descending"})
        st.write(fig_10)

    with col2:
        # Top 10 Load Failed Through Copy Command

        Top_10_Load_Failed_Through_Copy_Command = pd.read_sql(f"""SELECT
TO_DATE(c.LAST_LOAD_TIME) as LOAD_DATE
    ,c.STATUS
    ,c.TABLE_CATALOG_NAME as DATABASE_NAME
    ,c.TABLE_SCHEMA_NAME as SCHEMA_NAME
    ,c.TABLE_NAME
    ,CASE WHEN c.PIPE_NAME IS NULL THEN 'COPY' ELSE 'SNOWPIPE' END AS INGEST_METHOD
    ,SUM(c.ROW_COUNT) as ROW_COUNT
    ,SUM(c.ROW_PARSED) as ROWS_PARSED
    ,AVG(c.FILE_SIZE) as AVG_FILE_SIZE_BYTES
    ,SUM(c.FILE_SIZE) as TOTAL_FILE_SIZE_BYTES
    ,SUM(c.FILE_SIZE)/POWER(1024,1) as TOTAL_FILE_SIZE_KB
    ,SUM(c.FILE_SIZE)/POWER(1024,2) as TOTAL_FILE_SIZE_MB
    ,SUM(c.FILE_SIZE)/POWER(1024,3) as TOTAL_FILE_SIZE_GB
,SUM(c.FILE_SIZE)/POWER(1024,4) as TOTAL_FILE_SIZE_TB
,(w.CREDITS_USED) as total_credits
FROM "SNOWFLAKE"."ACCOUNT_USAGE"."COPY_HISTORY" c
join SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY w
where STATUS ='Load failed' and INGEST_METHOD ='COPY'
GROUP BY 1,2,3,4,5,6,CREDITS_USED
ORDER BY TOTAL_FILE_SIZE_GB desc limit 10;""", connection)
        # Create chart

        fig_10 = px.bar(Top_10_Load_Failed_Through_Copy_Command, x="table_name", y="total_file_size_gb",
                        color='total_file_size_gb', title="Top 10 Loads Failed Through Copy Command",
                        width=700, height=370,
                        labels={
                            "table_name": "Table Name",
                            "total_file_size_gb": "GB"
                        },
                        hover_name="table_name",
                        hover_data=['table_name', 'total_credits', 'schema_name', 'total_file_size_gb'])
        fig_10.update_layout(showlegend=False, xaxis={"categoryorder": "total descending"})
        st.write(fig_10)
@st.cache_data
def Role():
#     show_tables = pd.read_sql(f"""show tables in developer_db.health_schema """, connection)
#    # st.write(show_tables['name'])


#     if  "GRANTS_TO_ROLES" not in show_tables['name'] :
#         pass
#     else:
        # create_table= pd.read_sql(f"""create transient table "SNOWFLAKE"."ACCOUNT_USAGE".GRANTS_TO_ROLES as select * from "SNOWFLAKE"."ACCOUNT_USAGE"."GRANTS_TO_ROLES"  """, connection)
        


    col1, col2, col3= st.columns(3)



    cloned = pd.read_sql(f"""select distinct count(name) Total_roles, DEFAULT_ROLE from  SNOWFLAKE.ACCOUNT_USAGE.USERS
            where DEFAULT_ROLE='ACCOUNTADMIN' and deleted_on is null
            group by DEFAULT_ROLE """, connection)

        # No. of sysadmins
    SYSADMIN = pd.read_sql(f"""select 'SYSADMIN' as role,count(*) as count  from SNOWFLAKE.ACCOUNT_USAGE.USERS
            where DEFAULT_ROLE='SYSADMIN' """, connection)

        # Total count of SECURITYADMIN
    Total_count_of_SECURITYADMIN = pd.read_sql("""
            select 'SECURITYADMIN',count(*) from SNOWFLAKE.ACCOUNT_USAGE.USERS
            where DEFAULT_ROLE='SECURITYADMIN';
            """, connection)

        # Total cont of USERADMIN role users
    Total_cont_of_USERADMIN_role_users = pd.read_sql("""
            select 'USERADMIN',count(*) from SNOWFLAKE.ACCOUNT_USAGE.USERS
            where DEFAULT_ROLE='USERADMIN';
            """, connection)

    x = pd.read_sql("""
        select count(NAME) from  SNOWFLAKE.ACCOUNT_USAGE.ROLES where OWNER is not null ; 

        """, connection)

    y = pd.read_sql("""
        select  count(a.ROLE) from "SNOWFLAKE"."ACCOUNT_USAGE"."GRANTS_TO_USERS" as a
        join "SNOWFLAKE"."ACCOUNT_USAGE".GRANTS_TO_ROLES as b
        on a.ROLE=b.NAME
        where GRANT_OPTION='TRUE'
        and a.ROLE not in(select GRANTEE_NAME from "SNOWFLAKE"."ACCOUNT_USAGE".GRANTS_TO_ROLES where GRANTED_ON='ROLE' and GRANTED_TO='ROLE' and GRANT_OPTION='FALSE'
                        and GRANTED_BY is not NULL)
        group by a.ROLE;
        """, connection)

    col2.metric(value=int(Total_count_of_SECURITYADMIN['COUNT(*)'][0]), label='**SECURITYADMIN**')
    col3.metric(value=int(Total_cont_of_USERADMIN_role_users['COUNT(*)'][0]),label='**USERADMIN**')
    col1.metric(value=int(cloned['total_roles'][0]), label='**ACCOUNTADMIN**')
        # col4.metric(value=SYSADMIN['role'][0], delta=int(SYSADMIN['count'][0]), label=' ')
    col1.metric(label="**SYSADMIN**",value=(SYSADMIN['count'][0]))
    col2.metric(label='**CUSTOM ROLES**', value=x['COUNT(NAME)'])
    with col3:
        if y.empty:
            pass
        else:
            st.metric(label='**ORPHAN ROLES**',value=y['COUNT(A.ROLE)'])
    style_metric_cards()

    role_ = pd.read_sql("""
        select distinct NAME,GRANTEE_NAME from "SNOWFLAKE"."ACCOUNT_USAGE".GRANTS_TO_ROLES where GRANTED_ON = 'ROLE' order by grantee_name;
        """, connection)
        # st.write(role)
    graph = graphviz.Digraph()

    for x in range(len(role_)):
            graph.edge(role_['grantee_name'][x], role_['name'][x])
        #
        #
    st.graphviz_chart(graph)

    col1,col2=st.columns(2)
        # ///top 10 roles by users
    with col1:
            roles = pd.read_sql("""
            select distinct ROLE, count (ROLE) as no_of_users from "SNOWFLAKE"."ACCOUNT_USAGE"."GRANTS_TO_USERS" where DELETED_ON is null
            group by role
            order by no_of_users desc limit 5;
            """, connection)

            fig = px.bar(roles, y='no_of_users', x='role',color='role', title="Top 5 Roles by Users", width=700, height=370,
                        labels={"role": "Role", "no_of_users": "Users"})
            fig.update_layout(showlegend=False,xaxis={"categoryorder": "total descending"})
            st.write(fig)

    with col2:
            # idle_roles-------------------------------------------

            idle_roles = pd.read_sql("""

            select a.NAME,b.last_used from  SNOWFLAKE.ACCOUNT_USAGE.ROLES a  join

            (
            SELECT DISTINCT ROLE_NAME,datediff(day, max(END_TIME),current_timestamp) as last_used
            FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
            group by ROLE_NAME
            having last_used>15
            )
            b on b.ROLE_NAME=a.name;

            """, connection)

            fig1 = px.line(idle_roles, x='name', y='last_used', width=700, height=370,
                        labels={"name": "Role Names", "last_used": "Last Used"},
                        title='Idle Roles Since 15 Days')
            fig1.update_layout(showlegend=False, xaxis={"categoryorder": "total descending"})
            st.write(fig1)

    with col1:
            # credits_used_user-------------------------------------------------
            credits_used_user = pd.read_sql(""" 
            with USER_HOUR_EXECUTION_CTE as
            (select USER_NAME ,
                    WAREHOUSE_NAME ,
                    DATE_TRUNC('hour', START_TIME) as START_TIME_HOUR ,
                    SUM(EXECUTION_TIME) as USER_HOUR_EXECUTION_TIME
            from "SNOWFLAKE"."ACCOUNT_USAGE"."QUERY_HISTORY"
            where WAREHOUSE_NAME is not null
                and EXECUTION_TIME > 0
                and START_TIME >='2023-03-01'
                and START_TIME <= '2023-03-16'
            group by 1,
                        2,
                        3),
                HOUR_EXECUTION_CTE as
            (select START_TIME_HOUR ,
                    WAREHOUSE_NAME ,
                    SUM(USER_HOUR_EXECUTION_TIME) as HOUR_EXECUTION_TIME
            from USER_HOUR_EXECUTION_CTE
            group by 1,
                        2),
                APPROXIMATE_CREDITS as
            (select A.USER_NAME ,
                    C.WAREHOUSE_NAME ,
                    (A.USER_HOUR_EXECUTION_TIME/B.HOUR_EXECUTION_TIME)*C.CREDITS_USED as APPROXIMATE_CREDITS_USED
            from USER_HOUR_EXECUTION_CTE A
            join HOUR_EXECUTION_CTE B on A.START_TIME_HOUR = B.START_TIME_HOUR
            and B.WAREHOUSE_NAME = A.WAREHOUSE_NAME
            join "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY" C on C.WAREHOUSE_NAME = A.WAREHOUSE_NAME
            and C.START_TIME = A.START_TIME_HOUR),

            user_name as
            (
                select distinct NAME from SNOWFLAKE.ACCOUNT_USAGE.USERS where DELETED_ON is null
            )
            select a.USER_NAME as USER_NAME,
                a.WAREHOUSE_NAME as WAREHOUSE_NAME,
                SUM(a.APPROXIMATE_CREDITS_USED) as APPROXIMATE_CREDITS_USED
            from APPROXIMATE_CREDITS a join
            user_name b
            on a.USER_NAME=b.name
            group by 1,
                    2
            order by 3 desc limit 10;     

            """, connection)

            fig = px.bar(credits_used_user, y='user_name', x='approximate_credits_used', width=700, height=370,
                        color='warehouse_name',
                        labels={"warehouse_name": "Warehouse Name",
                                "approximate_credits_used": "Approximate Credits Used"},
                        title='Top 10 Credits Used Per User Since 30 days ')
            fig.update_layout(yaxis={"categoryorder": "total descending"})
            st.write(fig)

if __name__ == "__main__":

    if selected == "Account":
        Account()
    elif selected == "Storage":
        Storage()
    elif selected == "Warehouse":
        Warehouse()
    elif selected == "Miscellaneous":
        Miscellaneous()
    elif selected == 'Role Management':
        Role()



