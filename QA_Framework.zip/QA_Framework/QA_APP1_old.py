import snowflake.connector
import pandas as pd
from snowflake.sqlalchemy import URL
from sqlalchemy import create_engine
from streamlit_pandas_profiling import st_profile_report
import streamlit as st
import plotly.express as px
from st_aggrid import AgGrid
from datetime import date
import base64
import requests
#from streamlit_lottie import st_lottie

from pandas_profiling import profile_report
import numpy as np

## self color #9CA4B5, #989CB9, #819A74

###87CEEB, #4682B4, #87CEEB,#7F84AA)

@st.cache(allow_output_mutation=True)
def get_base64_of_bin_file(bin_file):
    with open(bin_file, 'rb') as f:
        data = f.read()
    return base64.b64encode(data).decode()

st.set_page_config(page_title="QA Framework")

def set_png_as_page_bg(png_file):
    bin_str = get_base64_of_bin_file(png_file)
    page_bg_img = '''
    <style>
    .stApp {
    background-image: url("data:image/png;base64,%s");
    background-size: cover;
    }
    </style>
    ''' % bin_str

    st.markdown(page_bg_img, unsafe_allow_html=True)
    return

png_file = ("/usr/share/nginx/html/qa_framework/image10.jpg")
set_png_as_page_bg(png_file)

conn = snowflake.connector.connect(**st.secrets['snowflake'])
with conn.cursor() as cur:
    cur.execute("select * from DEVELOPER_DB.QA_FRAMEWORK_SCHEMA.QA_RESULTS")
    res = cur.fetchall()
    df = pd.DataFrame(res, columns=['RULE_ID', 'RESULT_TABLE_NAME', 'RESULT', 'EXPECTED_RESULT', 'ACTUAL_RESULT',
                                    'RULE_DATE'])

df_vs = df
df_vs.RESULT.value_counts()

df_met = df
df_met_01 = df


df_met_01['RESULT'].value_counts().reindex(['Pass','Fail'], fill_value=0)
hide_st_style = """
            <style>
            MainMenu {visibility: show;}
            footer {visibility: hidden;}
            header {visibility: hidden;}
            </style>
            """
st.markdown(hide_st_style, unsafe_allow_html=True)

# st.markdown(
#
#          f"""sssss
#
#          <style>
#
#          .stApp {{
#
#              background: linear-gradient(to right,#3C3CA2, #7E7EE8, #9393D8, #9393D8,#7E7EE8,#3C3CA2);
#
#              background-size: cover
#
#          }}
#
#          </style>
#
#          """,
#
#          unsafe_allow_html=True
#
#      )

def load_lottieurl(url_01: str):
    r = requests.get(url_01)
    if r.status_code != 200:
        return None
    return r.json()

with conn.cursor() as cur:
    cur.execute("select distinct result from DEVELOPER_DB.QA_FRAMEWORK_SCHEMA.QA_RESULTS")
    res_1 = cur.fetchall()
# print(df)

with st.sidebar:
    st.image("https://5nnbe2.a2cdn1.secureserver.net/wp-content/uploads/2022/09/Boolean-logo_Boolean-logo-USA-1.png")

    st.title(':blue[QA Framework Model]')

    choice = st.radio(" ", ['QA Framework', "Profiling", "Insights 📈"])



    st.markdown("       ")
    st.markdown("       ")


    st.title(':blue[ABOUT BOOLEAN DATA]')

    st.write(

        """
         Boolean Data Systems is a Snowflake Select Services partner that implements
         solutions on cloud platforms. Our data experts are specialized in designing,
         building, and implementing data warehousing, analytics, and management 
         solutions using Snowflake's modern data platform to help enterprises make 
         better business decisions with data and solve real-world business analytics 
         and data problems.
        """)

    st.write("[Learn More>](https://booleandata.com/)")



if choice == "QA Framework":

    st.title('QA Framework')
    st.subheader("Add a new rule here 👇")

    url = URL(
        account='oseazbt-booleandata_partner',
        user='vikass@booleandata.com',
        password='Badmanraja1.'
    )
    engine = create_engine(url)
    connection = engine.connect()

    @st.cache(allow_output_mutation=True)
    def load_data_db():
        engine = create_engine(url)
        conn = engine.connect()
        sql = 'show databases'
        df_db = pd.read_sql(sql, con=conn)
        return df_db

    res_db = load_data_db()
    st_db = st.selectbox('**Select  Database**', res_db['name'])


    @st.cache(allow_output_mutation=True)
    def load_data_sh():
        engine = create_engine(url)
        conn = engine.connect()
        sql = 'show schemas'
        df_sh = pd.read_sql(sql,conn)
        return df_sh


    res_sh = load_data_sh()
    st_sh = st.selectbox('**Select Schema**', res_sh['name'])


    @st.cache(allow_output_mutation=True)
    def load_data_tbl():
        engine = create_engine(url)
        conn = engine.connect()
        sql = f"""show tables in {st_db}.{st_sh}"""
        df_tbl = pd.read_sql(sql, con=conn)
        return df_tbl


    res_tbl = load_data_tbl()
    st_tbl = st.selectbox('**Select Table**', res_tbl['name'])


    @st.cache(allow_output_mutation=True)
    def load_data_col():
        engine = create_engine(url)
        conn = engine.connect()
        sql = f'show columns in {st_db}.{st_sh}.{st_tbl} '
        df_col = pd.read_sql(sql, con=conn)
        return df_col


    res_col = load_data_col()
    st_cols = st.selectbox('**Select Column Name**', res_col['column_name'])

    rule_columns = st.selectbox('**Select Rule Column**', ['default', 'sum', 'count', 'avg'])




    rule_symbol = st.selectbox('**Select Rule Symbol**', ['>', '<', '=', 'is'])

    rule_value = st.text_input('**Select Rule Value**')


    @st.cache(allow_output_mutation=True)
    def load_data_date_col():
        engine = create_engine(url)
        conn = engine.connect()
        sql = f'show columns in {st_db}.{st_sh}.{st_tbl}'
        df_date_col = pd.read_sql(sql, con=conn)
        return df_date_col


    res_date_col = load_data_date_col()
    st_date_col = st.selectbox('**Select Date Column**', res_date_col['column_name'])


    Recipients = st.text_input('**Select Recipients**')




    row_count = pd.read_sql(f""" select rule_id from DEVELOPER_DB.QA_FRAMEWORK_SCHEMA.QA_Config_table  """, connection)

    if st.button('**Submit**'):
         try:
            if rule_columns == 'default':
                pd.read_sql(
                    f"""INSERT INTO DEVELOPER_DB.QA_FRAMEWORK_SCHEMA.QA_Config_table(RULE_ID,DB_NAME,SCHEMA_NAME,TABLE_NAME,RULE,RULE_COL,RULE_SYMBOL,DATE_COLUMN,ACTION,RECIPIENT,RULE_INSERT_DATE,RULE_UPDATE_DATE)
                     VALUES ('R_{len(row_count) + 1}','{st_db}','{st_sh}','{st_tbl}','{st_cols + ' ' + rule_symbol + ' ' + rule_value}','{st_cols}','{rule_symbol}','{st_date_col}','my_email_int',
                                        '{Recipients}','{date.today()}','{date.today()}')""", connection)

         except:

             st.error("Note: Rule value should not be empty, Please check")


         else:
             try:
                 pd.read_sql(
                     f"""INSERT INTO DEVELOPER_DB.QA_FRAMEWORK_SCHEMA.QA_Config_table VALUES('R_{len(row_count) + 1}','{st_db}','{st_sh}','{st_tbl}','{st_cols + ' ' + rule_symbol + ' ' + rule_value}','{rule_columns + '(' + st_cols + ')'}','{rule_symbol}',{rule_value},'{st_date_col}','my_email_int',
                                                         '{Recipients}','{date.today()}','{date.today()}')""",
                     connection)
                 st.success('Rule has been inserted successfully', icon="✅")
             except:

                 st.error("Note: Rule value should not be empty, Please check")







    QA_frame = pd.read_sql(f""" select * from DEVELOPER_DB.QA_FRAMEWORK_SCHEMA.QA_Config_table """, connection)
    df_02 = AgGrid(QA_frame)



    if st.button('**Trigger QA**'):
        with conn.cursor() as cur:
           cur.execute("call DEVELOPER_DB.QA_FRAMEWORK_SCHEMA.QA_FRAMEWORK_PROCEDURE('QA_Config_table')")
           st.success('Procedure has been called sucessfully 📤', icon="✅")
    QA_Results_streamlit = pd.read_sql(""" select * from DEVELOPER_DB.QA_FRAMEWORK_SCHEMA.QA_Results """,connection)
    df_03 = AgGrid(QA_Results_streamlit.head(20))

######## Data Profiling

if choice == "Profiling":
     st.title('Data Profiling')
     profilereport = df.profile_report(minimal=True)
     st_profile_report(profilereport)

######## Data Insaights

if choice == "Insights 📈":
    with st.spinner('Wait Visuals loading ...'):
     st.title("QA Framework Insights")

#### KPIs

     with open('file.css') as f:
      st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)

      st.subheader("QA Result KPI")

      kpi1, kpi2, kpi3 = st.columns(3)

      kpi1.metric("Total Result",
                  value=df_met_01["RESULT"].count())

      kpi2.metric(label="Total no of Pass ✅",
                  value=df_met_01[df_met_01['RESULT'] == 'Pass']['RESULT'].count())

      kpi3.metric(label="Total no of Fail ❌",
                  value=df_met_01[df_met_01['RESULT'] == 'Fail']['RESULT'].count())

      # kpi4.metric(label="Total no of Table 🉑",
      #             value=df_met_01['RESULT_TABLE_NAME'].nunique())

      st.markdown("       ")
      st.markdown("       ")

#### Visualization 01

     df_vs['RULE_DATE'] = pd.to_datetime(df_vs.RULE_DATE, format='%Y-%m-%d %H:%M:%S')
     df_vs['RULE_DATE'] = df_vs['RULE_DATE'].dt.strftime('%Y-%m-%d %H:%M:%S')

     Table_options = df_vs["RESULT_TABLE_NAME"].unique().tolist()
     Result_options = df_vs["RESULT"].unique().tolist()
     Table_name = st.multiselect('***Select Tables***', Table_options, ['CUSTOMER'])


     df_vs = df_vs[df_vs["RESULT_TABLE_NAME"].isin(Table_name)]


     st.markdown("       ")
     st.markdown("       ")

#### Visual 02
     figh = px.histogram(df_vs, x=df_vs['RESULT'], title='Total Result', color="RESULT_TABLE_NAME")

     st.plotly_chart(figh)

     st.markdown("       ")
     st.markdown("       ")


#### Visual 03

     result_val = df_vs['RESULT'].value_counts()


     fig_04 = px.pie(result_val, res_1, values=result_val, title="Result Insights of QA Framework")
     st.plotly_chart(fig_04)


     st.subheader("")
     col1, col2 = st.columns(2)

     x_axis_val = col1.selectbox('***Select The X-axis***', options=df_vs.columns)
     y_axis_val = col2.selectbox('***Select the Y-axis***', options=df_vs.columns)

     plot = px.bar(df_vs, x=x_axis_val, y=y_axis_val)
     st.plotly_chart(plot, use_container_width=True)

     st.subheader(""" Result Table of QA Framework """)
     df_01 = AgGrid(df.head(20))





