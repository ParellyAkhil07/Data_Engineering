import streamlit as st 
import pandas as pd 
import matplotlib.pyplot as plt
import numpy as np
import plotly.express as px
import base64
from PIL import Image



st.set_page_config(layout="wide",page_title="Snowflake Cost Estimator",page_icon="❄️")


col1,col2,col3=st.columns(3)

#page wide and boolean image 
with col1:
    a= Image.open("C:/Users/Kalyan/Desktop/snowflake estimator/snowflake image.png")
    st.image(a,width=150)
    # st.image ("C:/Users/Kalyan/Desktop/snowflake estimator/sf_image02.jpg")

#pagle title
with col2:
    st.markdown("<h1 style='text-align: center; color: black; background : rgbe(0,0,0,0)'>Cost Estimator </h1>", unsafe_allow_html=True)

with col3:
    pass

hide_st_style = """
            <style>
            MainMenu {visibility: hidden;}
            footer {visibility: hidden;}
            header {visibility: hidden;}
            </style>
            """
st.markdown(hide_st_style, unsafe_allow_html=True)
# background image and path
# @st.cache(allow_output_mutation=True)
# def get_base64_of_bin_file(bin_file):
#     with open(bin_file, 'rb') as f:
#         data = f.read()
#     return base64.b64encode(data).decode()

# def set_png_as_page_bg(png_file):
#     bin_str = get_base64_of_bin_file(png_file)
#     page_bg_img = '''
#     <style>
#     .stApp {
#     background-image: url("data:image/png;base64,%s");
#     background-size: cover;
#     }
#     </style>
#     ''' % bin_str

#     st.markdown(page_bg_img, unsafe_allow_html=True)
#     return

# png_file = ("C:/Users/Kalyan/Downloads/image_03.jpg")
# set_png_as_page_bg(png_file)

#KPI's
st.markdown("___")
col1,col2,col3,col4=st.columns([2,3,3,1])
capacity=col1.number_input("**Initial Data Size (in GB)**",0)
# col1.write(f'Cocol1 {capacity*0.025}$/GB')
cost_per_credit=col1.number_input('**Cost per Credit (in $)**')
warehouse_size = col1.selectbox('**Select Warehouse Size**',['X-Small', 'Small','Medium','Large','X-Large','2X-Large'])
dirt={'X-Small':1,'Small':2,'Medium':4,'Large':8,'X-Large':16,'2X-Large':32}
clusters=col1.number_input("**Number Of Cluster**",min_value=1,max_value=10)
data_load = col1.number_input('**Data Load Duration**',min_value=1)
consumed_hour=col1.number_input("**Credits Consumed per Hour**",dirt[warehouse_size]*int(clusters),disabled=True)
days_in_month=col1.number_input("**Days in Month**",min_value=1,max_value=31)
credits_req=col1.number_input("**Credits Required per Month**",data_load*consumed_hour*days_in_month,disabled=True)
compute_cost=col1.number_input("**Total Compute Cost per Month**",float(cost_per_credit)*credits_req,disabled=True)

# total cost

col3.metric(label="**Storage Cost**", value=f"$ {round(capacity*0.023,3)*12}")
col4.metric(label="**Compute Cost**", value=f"$ {round(compute_cost,2)*12}")
# col4.metric(label="**Compute Cost**", value=f"$ {(round(compute_cost,2)+(round(compute_cost,2)-consumed_hour)+(round(compute_cost,2)-(consumed_hour*3)))*12}")
col2.metric(label="**Total Annual Cost**", value=f"$ {round(capacity*0.023,3)*12 + round(compute_cost,2)*12}")

# month dataframe for graph

mon=[31,28,31,30,31,30,31,31,30,31,30,31]
comp=[]
for x in mon :
    if x == 31:
        comp.append(round(compute_cost,2))
    elif x == 30:
        comp.append(round(compute_cost,2)-consumed_hour)
    elif x == 28:
        comp.append(round(compute_cost,2)-(consumed_hour*3))

# month dataframe for graph
a={round(capacity*0.023,3)}
print(a)
ll={}
month_df = ['January', 'February', 'March', 'April', 'May', 'June', 'July','August', 'September', 'October', 'November', 'December']
for x in month_df:
    ll.update({x : [round(compute_cost,2)]})

data = ['January', 'February', 'March', 'April', 'May', 'June', 'July','August', 'September', 'October', 'November', 'December']
data2= [ x*(round(capacity*0.023,3)) for x in range(1,len(month_df)+1)]
data3=[round(capacity*0.023,3)+x for x in comp]
# print(data2)
# print(data3)


# data frame generation 

df = pd.DataFrame(data, columns=["Month"],index=None)

# graph creation

fig=px.line(y=data2, x=df['Month'],width=500,title="Commulative Storage Cost",height=400,labels={"x":"Months","y":"Storage Cost"})
col2.write(fig)

fig=px.line(y=comp, x=df['Month'],width=500,title='Compute Cost',height=400,labels={"x":"Months","y":"Compute Cost"})
col3.write(fig)

fig=px.line(y=data3, x=df['Month'],width=920,height=400,title="Total Cost",labels={"x":"Months","y":"Total Cost"})
col2.write(fig)




