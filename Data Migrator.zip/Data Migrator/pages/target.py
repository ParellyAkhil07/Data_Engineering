import pandas as pd
import streamlit as st
import pathlib
import os
from sqlalchemy import create_engine
from snowflake.sqlalchemy import URL
import snowflake.connector
import boto3
from PIL import Image
from streamlit.components.v1 import html
import psycopg2
import streamlit_extras
from streamlit_extras.switch_page_button import switch_page
import base64
import time
import pathlib
import re
import yaml
from streamlit_extras.add_vertical_space import add_vertical_space

def get_base64_of_bin_file(bin_file):
	with open(bin_file, 'rb') as f:
		data = f.read()
	return base64.b64encode(data).decode()
def set_png_as_page_bg(png_file):
	bin_str = get_base64_of_bin_file(png_file)
	page_bg_img = '''    
	<style>    
	.stApp {    
	background-image: url("data:image/png;base64,%s");    
	background-size: cover;    
	}                
	[id="root"]{        
	}    
	</style>    
	''' % bin_str
	st.markdown(page_bg_img, unsafe_allow_html=True)
	return
set_png_as_page_bg("tra.jpg")


st.markdown("""
<style>

[data-testid="stForm"]{
    background: white;
    border-radius: 25px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

.css-10trblm.e16nr0p30{
text-transform: uppercase;
	background: linear-gradient(to right, #30CFD0 0%, #330867 100%);
	-webkit-background-clip: text;
	-webkit-text-fill-color: transparent;
	font: {
		size: 20vw;
		family: $font;
	};

}


[data-testid="stSidebar"]{
display: none;


</style>
""",unsafe_allow_html=True)

st.title('DATA MIGRATOR')

add_vertical_space(3)
st.header('Target')
with st.form('snowflake'):
    col1, col2 = st.columns(2)
    snowflake_user = st.text_input('**Snowflake User**','vikass@booleandata.com', key='snowflake_user')
    snowflake_password = st.text_input('**Snowflake Password**', 'Badmanraja1.',type='password')
    snowflake_account = st.text_input('**Snowflake Account**','oseazbt-booleandata_partner')

    # if st.form_submit_button('Test Connection'):
    con = snowflake.connector.connect(
        user=snowflake_user,
        password=snowflake_password,
        account=snowflake_account
        )
    if con:
        st.success('Successfully connected to Snowflake')
        cursor = con.cursor()
        col1, col2 = st.columns(2)
        cursor.execute("SHOW DATABASES")
        databases = [row[1] for row in cursor]
        selected_database = col1.selectbox('**Database**', databases, )

        cursor.execute("SHOW SCHEMAS")
        schemas = [row[1] for row in cursor]
        selected_schema = col2.selectbox('**Schema**', schemas, )

        with col1:
            if st.form_submit_button("Connect"):



                data = dict(
                    snowflake_user=snowflake_user,
                    snowflake_password=snowflake_password,
                    snowflake_account=snowflake_account,
                    selected_database=selected_database,
                    selected_schema=selected_schema,
                )

                with open('snowflake.yml', 'w') as outfile:
                    yaml.dump(data, outfile, default_flow_style=False)
                switch_page('migrator')




    else:
        st.error('Please check connection')

    with col2:
        if st.form_submit_button('Previous'):
            switch_page('main')









