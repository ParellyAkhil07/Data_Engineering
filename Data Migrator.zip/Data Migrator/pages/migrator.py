import datetime
import logging
import smtplib
import sys
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import pandas as pd
import streamlit as st
import pathlib
import os
from sqlalchemy import create_engine
from snowflake.sqlalchemy import URL
import snowflake.connector
import boto3
from PIL import Image
from streamlit.components.v1 import html
import psycopg2
import streamlit_extras
from streamlit_extras.switch_page_button import switch_page
from datetime import datetime
import io
import gzip
import base64
import time
from stqdm import stqdm
from time import sleep
import pyodbc
from sql_server import sql_server
import yaml
from mysql import my_sql
from post import postsql
from streamlit_extras.add_vertical_space import add_vertical_space

def get_base64_of_bin_file(bin_file):
	with open(bin_file, 'rb') as f:
		data = f.read()
	return base64.b64encode(data).decode()
def set_png_as_page_bg(png_file):
	bin_str = get_base64_of_bin_file(png_file)
	page_bg_img = '''    
	<style>    
	.stApp {    
	background-image: url("data:image/png;base64,%s");    
	background-size: cover;    
	}                
	[id="root"]{        
	}    
	</style>    
	''' % bin_str
	st.markdown(page_bg_img, unsafe_allow_html=True)
	return
set_png_as_page_bg("mig.jpg")

st.markdown("""
<style>

[data-testid="stForm"]{
    background: white;
    border-radius: 25px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

.css-10trblm.e16nr0p30{
text-transform: uppercase;
	background: linear-gradient(to right, #30CFD0 0%, #330867 100%);
	-webkit-background-clip: text;
	-webkit-text-fill-color: transparent;
	font: {
		size: 20vw;
		family: $font;
	};

}

[data-testid="stSidebar"]{
display: none;

</style>
""",unsafe_allow_html=True)

st.markdown('<img src="./sour.gif"/>', unsafe_allow_html=True)

st.title('DATA MIGRATOR')

add_vertical_space(3)
st.header('Migrator')
f=open('pages/data.txt','r')
database = f.read()

if database =='SQL Server':
	sql_server(database)
elif database =='Mysql':
	my_sql(database)
elif database =='Postgresql':
	postsql(database)


