import pandas as pd
import streamlit as st
import pathlib
import os
from sqlalchemy import create_engine
from snowflake.sqlalchemy import URL
import snowflake.connector
import boto3
from PIL import Image
from streamlit.components.v1 import html
import psycopg2
import streamlit_extras
from streamlit_extras.switch_page_button import switch_page
import base64
import time
import pandas as pd
import os
from datetime import datetime
import pathlib
from sqlalchemy import create_engine
import time
from datetime import datetime
from sqlalchemy.engine import URL
import boto3
import logging,sys
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import gzip
import pyodbc
from snowflake.sqlalchemy import URL
import pymysql
from sqlalchemy import MetaData
from streamlit_extras.add_vertical_space import add_vertical_space
import base64
import streamlit.components.v1 as components
import yaml

# button css
st.set_page_config(layout="centered",page_title='Datamigrator')
def get_base64_of_bin_file(bin_file):
	with open(bin_file, 'rb') as f:
		data = f.read()
	return base64.b64encode(data).decode()
def set_png_as_page_bg(png_file):
	bin_str = get_base64_of_bin_file(png_file)
	page_bg_img = '''    
	<style>    
	.stApp {    
	background-image: url("data:image/png;base64,%s");    
	background-size: cover;    
	}                
	[id="root"]{        
	}    
	</style>    
	''' % bin_str
	st.markdown(page_bg_img, unsafe_allow_html=True)
	return
set_png_as_page_bg("src.jpg")


st.markdown("""
<style>

[data-testid="stForm"]{
    background: white;
    border-radius: 25px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
    
.css-10trblm.e16nr0p30{
text-transform: uppercase;
	background: linear-gradient(to right, #30CFD0 0%, #330867 100%);
	-webkit-background-clip: text;
	-webkit-text-fill-color: transparent;
	font: {
		size: 20vw;
		family: $font;
	};

}

[data-testid="stSidebar"]{
display: none;
}
</style>
""",unsafe_allow_html=True)


st.title('DATA MIGRATOR')

add_vertical_space(3)
st.header('Source')
database = st.selectbox('**Select Database**', ('SQL Server','Postgresql','Mysql'),key='database')
if 'database' not in st.session_state:
    st.session_state.database = database

f=open('pages/data.txt',"w")
f.write(f'{database}')
col1,col2=st.columns(2)

def sql_server():
	with st.form("Sql_server"):

		col1, col2 = st.columns(2)


		# st.subheader('Source')
		sql_server_user = col1.text_input('**SQL Server User**','admin')
		sql_server_password = col1.text_input('**SQL Server Password**','L400p->8j|G`skh+', type='password')
		sql_server_hostname = st.text_input('**SQL Server Host**','database-2.c5acjh9wfmjl.ap-south-2.rds.amazonaws.com')
		sql_server_port = col2.text_input('**SQL Server Port**','1444')
		sql_server_database = col2.text_input('**SQL Server Database**','sql_server_data_migration')
		sql_server_servername = f'{sql_server_hostname},{sql_server_port}'
		if st.form_submit_button('Connect'):
			try:
				sql_server_cnxn = create_engine(
					f'mssql+pyodbc://{sql_server_user}:{sql_server_password}@{sql_server_servername}/{sql_server_database}?driver=SQL+Server')
				engine_con = sql_server_cnxn.connect()
			except:
				st.error("please Check Connection Details !")
			if engine_con:
				data = dict(
					sql_server_user=sql_server_user,
					sql_server_password=sql_server_password,
					sql_server_database=sql_server_database,
					sql_server_servername=sql_server_servername,
				)

				with open('sqlserver.yml', 'w') as outfile:
					yaml.dump(data, outfile, default_flow_style=False)
				st.success("Sqlserver Connected sucessfully")
				switch_page("target")






def my_sql():
	with st.form("my_sql"):
		col1, col2 = st.columns(2)
		user = col1.text_input('**User**','admin')
		password = col1.text_input('**Password**','Y1?a?Roki4ROVesOcRUs', type='password')
		hostname = st.text_input('**Host**','database-3.c5acjh9wfmjl.ap-south-2.rds.amazonaws.com')
		port = col2.text_input('**Port**','3306')
		database_name = col2.text_input('**Database**','Mysql_db')

		if st.form_submit_button("Connect"):
			try:
				table_engine = create_engine(
					f"mysql+pymysql://{user}:{password}@{hostname}:{port}/{database_name}")
				engine_con = table_engine.connect()
			except:
				st.error("please Check Connection Details !")
			if engine_con:
				data = dict(
						mysql_user=user,
						mysql_password=password,
						mysql_dbname=database_name,
						mysql_host=hostname,
						mysql_port=port,
					)

				with open('sqlserver.yml', 'w') as outfile:
					yaml.dump(data, outfile, default_flow_style=False)
				st.success("Mysql Connected sucessfully")
				switch_page("target")



def post_sql():
	with st.form('post'):
		col1, col2 = st.columns(2)
		user = col1.text_input('**User**','postgres')
		password = col1.text_input('**Password**','BRAF+ocr1x+*tuP3-sI&', type='password')
		hostname = st.text_input('**Host**','database-1.c5acjh9wfmjl.ap-south-2.rds.amazonaws.com')
		port = col2.text_input('**Port**','5444')
		database_name = col2.text_input('**Database**','booleandata')

		if st.form_submit_button("Connect"):
			try:
				table_engine = create_engine(
					f'postgresql+psycopg2://{user}:{password}@{hostname}:{port}/{database_name}')
				engine_con = table_engine.connect()
			except:
				st.error("please Check Connection Details !")
			if engine_con:
				data = dict(
						post_sql_user=user,
						post_sql_password=password,
						post_sql_dbname=database_name,
						post_sql_host=hostname,
						post_sql_port=port,
					)

				with open('sqlserver.yml', 'w') as outfile:
					yaml.dump(data, outfile, default_flow_style=False)
				st.success("Postgre Connected sucessfully")
				switch_page("target")


if database =='SQL Server':
	sql_server()
elif database =='Mysql':
	my_sql()
elif database =='Postgresql':
	post_sql()

