import pandas as pd
import os
from datetime import datetime
import pathlib
from sqlalchemy import create_engine
import time
from datetime import datetime
from sqlalchemy.engine import URL
import boto3
import logging,sys
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders   
import gzip
import pyodbc
from snowflake.sqlalchemy import URL
# import mysql.connector
import pymysql
from sqlalchemy import MetaData
import yaml
import streamlit as st
from stqdm import stqdm

parm_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), f"connect.params")
param_file_path = pathlib.Path(parm_file)
parameters = {}
if param_file_path.exists():
    file_obj = open(parm_file)
    for line in file_obj:
        line = line.strip()
        if not line.startswith('#'):
            key_value = line.split('=')
            if len(key_value) == 2:
                parameters[key_value[0].strip()] = key_value[1].strip()
# print(parameters)

def my_sql(database):
    with open(r'C:\Users\Vikas Sony\Desktop\migrator_3.0\snowflake.yml') as file:
        snow = yaml.load(file, Loader=yaml.FullLoader)

    snowflake_account = snow["snowflake_account"]
    snowflake_user = snow["snowflake_user"]
    snowflake_password = snow["snowflake_password"]
    snowflake_database = snow["selected_database"]
    snowflake_schema = snow["selected_schema"]
    snowflake_warehouse = parameters['snowflake_warehouse']
    snowflake_stage = parameters['snowflake_stage'].upper()

    with open(r'C:\Users\Vikas Sony\Desktop\migrator_3.0\sqlserver.yml') as file:
        doc = yaml.load(file, Loader=yaml.FullLoader)

    mysql_dbname = doc['mysql_dbname']
    mysql_host = doc['mysql_host']
    mysql_user = doc['mysql_user']
    mysql_password = doc['mysql_password']
    mysql_port=doc['mysql_port']

    aws_key_id = parameters['aws_access_key_id']
    aws_secret_key = parameters['aws_secret_access_key']
    aws_bucket_name = parameters['aws_s3_Bucket_name']
    aws_bucket_prefix = parameters['aws_Mysql_bucket_prefix']

    table_engine = create_engine(
        f"mysql+pymysql://{mysql_user}:{mysql_password}@{mysql_host}:{mysql_port}/{mysql_dbname}")
    engine_con = table_engine.connect()
    ki = engine_con.execute(
        f""" use {mysql_dbname}""")

    kj = engine_con.execute(f"""show tables""")
    my_sql_database = st.selectbox(f'**{mysql_dbname} Database**', [mysql_dbname, ])
    tables = [x[0] for x in kj]
    my_sql_table_name = st.multiselect(f'**{database} Tables**', tables)




    def mysql_db_table_list():
        table_list1=[]
        table_engine = create_engine(f"mysql+pymysql://{mysql_user}:{mysql_password}@{mysql_host}:{mysql_port}/{mysql_dbname}")
        engine_con = table_engine.connect()
        metadata = MetaData()
        metadata.reflect(bind=table_engine)
        table_names = metadata.tables.keys()
        for tables in table_names:
            table_list1.append(tables)
        return table_list1


    def mysql_db_table_data_extraction(table_name):
        # table_engine = create_engine("mysql+pymysql://admin:Y1?a?Roki4ROVesOcRUs@database-3.c5acjh9wfmjl.ap-south-2.rds.amazonaws.com:3306/dibyajyotidb")
        table_engine = create_engine(f"mysql+pymysql://{mysql_user}:{mysql_password}@{mysql_host}:{mysql_port}/{mysql_dbname}")
        sql = """ SELECT * FROM {schema_name}.{table_name} """.format(table_name=table_name, schema_name=mysql_dbname)
        engine_con = table_engine.connect()
        table_data_df = pd.read_sql(sql, engine_con)
        engine_con.close()
        table_engine.dispose()
        csv_data = table_data_df.to_csv(sep='|',index=False,header=True)
        s3 = boto3.client("s3", aws_access_key_id=aws_key_id, aws_secret_access_key=aws_secret_key )
        s3.put_object(Bucket=aws_bucket_name, Key=aws_bucket_prefix+'/'+table_name+'.csv', Body=csv_data )
        s3_client = boto3.client('s3')
        s3 = boto3.resource('s3', aws_access_key_id=aws_key_id, aws_secret_access_key=aws_secret_key)
        obj = s3.Object("dibyajyotibucket", f'{aws_bucket_prefix}/{table_name}.csv')
        table_data_df = pd.read_csv(obj.get()['Body'], sep='|', quotechar='"')
        return table_data_df
        # return print("CSV file uploaded to S3 bucket!")


    def snowflake_stage_creation():
        stage_exist_sql = f"select stage_name from {snowflake_database}.INFORMATION_SCHEMA.STAGES where STAGE_SCHEMA='{snowflake_schema}' and STAGE_NAME= '{snowflake_stage}'"
        # print(stage_exist_sql)
        engine = create_engine(URL(
            account = snowflake_account,
            user = snowflake_user,
            password=snowflake_password,
            database=snowflake_database,
            schema=snowflake_schema,
            warehouse=snowflake_warehouse
            ))

        connection = engine.connect()
        stage_exist = connection.execute(stage_exist_sql)
        stage_pd = pd.DataFrame(stage_exist)
        stage_creation_sql = f" create  stage {snowflake_database}.{snowflake_schema}.{snowflake_stage} url ='s3://{aws_bucket_name}/{aws_bucket_prefix}/' \
                                credentials =(aws_key_id= '{aws_key_id}', \
                                aws_secret_key='{aws_secret_key}') "
        # print(stage_pd.empty)
        if stage_pd.empty:
            connection.execute(stage_creation_sql)
            print(f"external stage {snowflake_stage} has been created..!")
        # else:
        #     print(f"external stage {snowflake_stage} has aleady existed..!")
        connection.close()

    def snowflake_table_data_load(table_data_df,table_name):
        engine = create_engine(URL(
            account=snowflake_account,
            user=snowflake_user,
            password=snowflake_password,
            database=snowflake_database,
            schema=snowflake_schema,
            warehouse=snowflake_warehouse,
        ))

        connection = engine.connect()
        snowflake_stage_creation()
        gz_file_name = table_name+'.csv'
        table_exist_sql = f"select distinct table_name from {snowflake_database}.INFORMATION_SCHEMA.tables where table_name ='{table_name.upper()}' and TABLE_SCHEMA='{snowflake_schema}'"
        table_exist = connection.execute(table_exist_sql)
        table_pd = pd.DataFrame(table_exist)
        # print(table_pd)

        if table_pd.empty:
            table_data_df.head(0).to_sql(name=table_name.upper(), con=connection, index=False)
            print(f"{table_name} table has been created in snowflake..!")
            start_time = datetime.now()
            connection.execute(
                f"""copy into "{snowflake_database}"."{snowflake_schema}"."{table_name.upper()}" from @{snowflake_database}.{snowflake_schema}.{snowflake_stage} FILE_FORMAT = (TYPE = CSV FIELD_DELIMITER = '|' SKIP_HEADER = 1 error_on_column_count_mismatch=false) ON_ERROR=CONTINUE files=('{gz_file_name}') """)
            end_time = datetime.now()
            total_load_time = ((end_time-start_time).total_seconds())/60
            load_time_list.append([gz_file_name,start_time, end_time, total_load_time])
        else:
            print("table already exists......")


    def mysql_validation_data(table_name):
        table_name = table_name
        count_sql = f"SELECT COUNT(*) from {table_name}"
        try:
            eng = create_engine(f"mysql+pymysql://{mysql_user}:{mysql_password}@{mysql_host}:{mysql_port}/{mysql_dbname}")
            Mysql_row_count = pd.read_sql(count_sql, eng)
        except Exception as Argument:
            logging.exception("Table or column name not found in Sqlserver")
            sys.exit('Error!')

        sf_count_sql = f""" SELECT COUNT(*) from "{snowflake_database}"."{snowflake_schema}"."{table_name.upper()}" """
        engine = create_engine(URL(
            account=snowflake_account,
            user=snowflake_user,
            password=snowflake_password,
            database=snowflake_database,
            schema=snowflake_schema,
            warehouse=snowflake_warehouse
        ))
        con = engine.connect()
        sf_row_count = pd.read_sql(sf_count_sql, con)
        con.close()
        final_df = pd.DataFrame(columns=['Table_Name', 'Mysql_Row_Count', 'Snowflake_Row_Count'])
        final_df['Mysql_Row_Count'], final_df['Snowflake_Row_Count'] = [Mysql_row_count.values[0],  sf_row_count.values[0]]
        final_df['Table_Name'] = table_name
        return final_df

    def send_mail_notification(file_name):
        msg = MIMEMultipart()
        msg['From'] = 'jyotir@booleandata.com'
        msg['To'] = 'jyotir@booleandata.com'
        msg['Subject'] = "Data Migration Status Notification"
        sender_email_id_password = 'Now61653'
        body = "Data load has successfully completed and the attached file is stats of the data"
        msg.attach(MIMEText(body, 'plain'))
        file_name = file_name
        attachment = open(file_name, "rb")
        p = MIMEBase('application', 'octet-stream')
        p.set_payload((attachment).read())
        encoders.encode_base64(p)
        p.add_header('Content-Disposition', "attachment; filename= %s" % file_name)
        msg.attach(p)
        s = smtplib.SMTP('smtp.office365.com', 587)
        s.starttls()
        s.login('jyotir@booleandata.com', sender_email_id_password)
        text = msg.as_string()
        s.sendmail('jyotir@booleandata.com', 'jyotir@booleandata.com', text)
        s.quit()

    # if __name__ == '__main__':
    if st.button("Connect"):
        data_load_state = st.text('Loading data...')

        # table_exist= pd.read_sql(""" snowflake_table_data_load.connection""")

        load_time_list = []
        start_of_process = datetime.now()
        # table_list = mysql_db_table_list()
        # print(table_list)
        validation_dataframes = pd.DataFrame(columns=['Table_Name', 'Mysql_Row_Count', 'Snowflake_Row_Count'])
        for table_name in my_sql_table_name:
            # print(table_name)
            table_data_df = mysql_db_table_data_extraction(table_name)
            snowflake_table_data_load(table_data_df, table_name)

        for table_name in my_sql_table_name:
            final = mysql_validation_data(table_name)
            frames = [validation_dataframes, final]
            validation_dataframes = pd.concat(frames, axis=0, ignore_index=True)

        load_time_df = pd.DataFrame(load_time_list,
                                    columns=['aws_s3_filename', 'start_time', 'end_time', 'total_load_time'])
        validation_dataframes['Difference'] = validation_dataframes['Mysql_Row_Count'] - validation_dataframes[
            'Snowflake_Row_Count']

        final_df = [validation_dataframes, load_time_df]
        final_result_df = pd.concat(final_df, axis=1)

        final_result_df.to_csv("Mysql_Data_Migration_Status.csv", index=False)
        # send_mail_notification("Redshift_validation_file.csv")
        end_of_process = datetime.now()

        print("total time taken for loading is",
              divmod((end_of_process - start_of_process).total_seconds(), 60))
        data_load_state.text(" ")
        for x in stqdm(range(len(my_sql_table_name)), backend=False):
            for y in stqdm(range(15), desc=f"{my_sql_table_name[x]}"):
                time.sleep(0.5)
        send_mail_notification("Mysql_Data_Migration_Status.csv")
        st.success('Data Sucessfully Migrated to Snowflake')