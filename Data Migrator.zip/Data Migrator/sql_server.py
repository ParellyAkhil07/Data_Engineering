import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import datetime
import logging
import smtplib
import sys
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import pandas as pd
import streamlit as st
import pathlib
import os
from sqlalchemy import create_engine
from snowflake.sqlalchemy import URL
import snowflake.connector
import boto3
from PIL import Image
from streamlit.components.v1 import html
import psycopg2
import streamlit_extras
from streamlit_extras.switch_page_button import switch_page
from datetime import datetime
import io
import gzip
import base64
import time
from stqdm import stqdm
from time import sleep
import pyodbc
import yaml

parm_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), f"connect.params")
param_file_path = pathlib.Path(parm_file)
parameters = {}
if param_file_path.exists():
    file_obj = open(parm_file)
    for line in file_obj:
        line = line.strip()
        if not line.startswith('#'):
            key_value = line.split('=')
            if len(key_value) == 2:
                parameters[key_value[0].strip()] = key_value[1].strip()

aws_key_id = parameters['aws_access_key_id']
aws_secret_key = parameters['aws_secret_access_key']
aws_bucket_name = parameters['aws_s3_Bucket_name']
aws_bucket_prefix = parameters['aws_sqlserver_bucket_prefix']
def sql_server(database):
    with st.form('sql'):


        with open(r'sqlserver.yml') as file:
            doc = yaml.load(file, Loader=yaml.FullLoader)

        sqlserver_user = doc["sql_server_user"]
        sqlserver_password = doc["sql_server_password"]
        sqlserver_host = doc["sql_server_servername"]
        sqlserver_dbname = doc["sql_server_database"]

        with open(r'snowflake.yml') as file:
            snow = yaml.load(file, Loader=yaml.FullLoader)

        snowflake_account = snow["snowflake_account"]
        snowflake_user= snow["snowflake_user"]
        snowflake_password = snow["snowflake_password"]
        snowflake_database= snow["selected_database"]
        snowflake_schema = snow["selected_schema"]
        snowflake_warehouse = parameters['snowflake_warehouse']
        snowflake_stage = parameters['snowflake_stage'].upper()






        cnxn = create_engine(
                    f'mssql+pyodbc://{sqlserver_user}:{sqlserver_password}@{sqlserver_host}/{sqlserver_dbname}?driver=SQL+Server')
        engine_con = cnxn.connect()


        kk = engine_con.execute(f"""SELECT name FROM sys.databases where name='{sqlserver_dbname}' """)
        Database = [x[0] for x in kk]
        sqlserver_database = st.selectbox(f'**{database} Database**', Database, )

        kj = engine_con.execute("""SELECT name FROM sys.schemas """)
        schema = [x[0] for x in kj]
        sqlserver_schema = st.selectbox(f'**{database} Schema**', schema)

        ki = engine_con.execute(
                    f""" SELECT t.name AS TABLE_NAME FROM sys.schemas AS s JOIN sys.tables AS t ON t.schema_id = s.schema_id where s.name= '{sqlserver_schema}'""")
        tables = [x[0] for x in ki]
        sql_table_name = st.multiselect(f'**{database} Tables**', tables)


        def sqlserver_db_table_list():
            table_engine = create_engine(
                f'mssql+pyodbc://{sqlserver_user}:{sqlserver_password}@{sqlserver_host}/{sqlserver_dbname}?driver=SQL+Server')
            engine_con = table_engine.connect()

            table_list_df = pd.read_sql(
                f""" SELECT t.name AS TABLE_NAME FROM sys.schemas AS s JOIN sys.tables AS t ON t.schema_id = s.schema_id where s.name='{sqlserver_schema}' and t.name in ('{sql_table_name}'); """,
                engine_con)
            # print(f""" SELECT t.name AS TABLE_NAME FROM sys.schemas AS s JOIN sys.tables AS t ON t.schema_id = s.schema_id where s.name='{sqlserver_schema}' and t.name in ('{sql_table_name}'); """


        def sqlserver_db_table_data_extraction(table_name):
            eng = create_engine(
                f'mssql+pyodbc://{sqlserver_user}:{sqlserver_password}@{sqlserver_host}/{sqlserver_dbname}?driver=SQL+Server')

            sql = """ SELECT * FROM [{schema_name}].[{table_name}] """.format(table_name=table_name,
                                                                              schema_name=sqlserver_schema)
            # print(sql)
            engine_con = eng.connect()
            table_data_df = pd.read_sql(sql, engine_con)
            engine_con.close()
            eng.dispose()
            csv_buffer = io.BytesIO()
            with gzip.GzipFile(mode='w', fileobj=csv_buffer) as gz_file:
                table_data_df.to_csv(gz_file, sep='|', index=False, header=True)
            s3 = boto3.client("s3", aws_access_key_id=aws_key_id, aws_secret_access_key=aws_secret_key)
            s3.put_object(Bucket=aws_bucket_name, Key=aws_bucket_prefix + '/' + table_name + '.gz',
                          Body=csv_buffer.getvalue())
            s3_client = boto3.client('s3')
            s3 = boto3.resource('s3', aws_access_key_id=aws_key_id, aws_secret_access_key=aws_secret_key)
            obj = s3.Object(aws_bucket_name, f'{aws_bucket_prefix}/{table_name}.gz')
            table_data_df = pd.read_csv(obj.get()['Body'], compression='gzip', sep='|', quotechar='"')
            return table_data_df
            # return print("CSV file uploaded to S3 bucket!")


        def snowflake_stage_creation():
            stage_exist_sql = f"select stage_name from {snowflake_database}.INFORMATION_SCHEMA.STAGES where STAGE_SCHEMA='{snowflake_schema}' and STAGE_NAME= '{snowflake_stage}'"
            # print(stage_exist_sql)
            engine = create_engine(URL(
                account=snowflake_account,
                user=snowflake_user,
                password=snowflake_password,
                database=snowflake_database,
                schema=snowflake_schema,
                warehouse=snowflake_warehouse
            ))

            connection = engine.connect()
            connection.execute(f"""use warehouse {snowflake_warehouse}""")
            stage_exist = connection.execute(stage_exist_sql)

            stage_pd = pd.DataFrame(stage_exist)
            stage_creation_sql = f" create  stage {snowflake_database}.{snowflake_schema}.{snowflake_stage} url ='s3://{aws_bucket_name}/{aws_bucket_prefix}/' \
                                        credentials =(aws_key_id= '{aws_key_id}', \
                                        aws_secret_key='{aws_secret_key}') "
            # print(stage_pd.empty)
            if stage_pd.empty:
                connection.execute(stage_creation_sql)
                print(f"external stage {snowflake_stage} has been created..!")
            # else:
            #     print(f"external stage {snowflake_stage} has aleady existed..!")
            connection.close()


        def snowflake_table_data_load(table_data_df, table_name):
            engine = create_engine(URL(
                account=snowflake_account,
                user=snowflake_user,
                password=snowflake_password,
                database=snowflake_database,
                schema=snowflake_schema,
                warehouse=snowflake_warehouse,
            ))

            connection = engine.connect()
            snowflake_stage_creation()
            gz_file_name = table_name + '.gz'
            table_exist_sql = f"select distinct table_name from {snowflake_database}.INFORMATION_SCHEMA.tables where table_name ='{table_name}' and TABLE_SCHEMA='{snowflake_schema}'"
            # print("sql is",table_exist_sql)
            table_exist = connection.execute(table_exist_sql)
            table_pd = pd.DataFrame(table_exist)
            if table_pd.empty:
                # print("Head is..",table_data_df.head(0))
                table_data_df.head(0).to_sql(name=table_name.upper(), con=connection, index=False)
                print(f"{table_name} table has been created in snowflake..!")
                # print( f"copy into {table_name} from @{snowflake_database}.{snowflake_schema}.{snowflake_stage} FILE_FORMAT = (TYPE = CSV FIELD_DELIMITER = '|') ON_ERROR=CONTINUE files=('{gz_file_name}')")
                start_time = datetime.now()
                connection.execute(
                    f"""copy into "{snowflake_database}"."{snowflake_schema}"."{table_name.upper()}" from @{snowflake_database}.{snowflake_schema}.{snowflake_stage} FILE_FORMAT = (TYPE = CSV FIELD_DELIMITER = '|' SKIP_HEADER = 1 error_on_column_count_mismatch=false) ON_ERROR=CONTINUE files=('{gz_file_name}') """)
                end_time = datetime.now()
                # total_load_time = divmod(((end_time - start_time)).total_seconds(), 60)
                total_load_time = ((end_time - start_time).total_seconds()) / 60
                # # print("load time is", total_load_time)
                load_time_list.append([gz_file_name, start_time, end_time, total_load_time])
            else:
                st.warning(f"{table_name} table already exist")


        def sqlserver_validation_data(table_name):
            table_name = table_name
            count_sql = f"SELECT COUNT(*) from [{sqlserver_schema}].[{table_name}]"
            try:

                eng = create_engine(
                    f'mssql+pyodbc://{sqlserver_user}:{sqlserver_password}@{sqlserver_host}/{sqlserver_dbname}?driver=SQL+Server')
                sqlserver_row_count = pd.read_sql(count_sql, eng)
            except Exception as Argument:
                logging.exception("Table or column name not found in Sqlserver")
                sys.exit('Error!')

            sf_count_sql = f""" SELECT COUNT(*) from "{snowflake_database}"."{snowflake_schema}"."{table_name.upper()}" """
            engine = create_engine(URL(
                account=snowflake_account,
                user=snowflake_user,
                password=snowflake_password,
                database=snowflake_database,
                schema=snowflake_schema,
                warehouse=snowflake_warehouse
            ))

            con = engine.connect()
            # b = con.execute(count_sql)
            sf_row_count = pd.read_sql(sf_count_sql, con)
            con.close()
            # print(b)
            final_df = pd.DataFrame(columns=['Table_Name', 'Sqlserver_Row_Count', 'Snowflake_Row_Count'])
            # final_df = pd.DataFrame({"name": ["table_name"], "ora_count": [a.values[0]], "snow_count": [b.values[0]]})
            # print(table_name)
            final_df['Sqlserver_Row_Count'], final_df['Snowflake_Row_Count'] = [sqlserver_row_count.values[0],
                                                                                sf_row_count.values[0]]
            final_df['Table_Name'] = table_name
            return final_df


        def send_mail_notification(file_name):
            msg = MIMEMultipart()
            msg['From'] = 'vikass@booleandata.com'
            msg['To'] = 'nagarjunas@booleandata.com,sunilm@booleandata.com'
            msg['Subject'] = "Data Migration Status Notification"
            sender_email_id_password = 'Mad52728'
            body = "Data load has successfully completed and the attached file is stats of the data"
            msg.attach(MIMEText(body, 'plain'))
            file_name = file_name
            attachment = open(file_name, "rb")
            p = MIMEBase('application', 'octet-stream')
            p.set_payload((attachment).read())
            encoders.encode_base64(p)
            p.add_header('Content-Disposition', "attachment; filename= %s" % file_name)
            msg.attach(p)
            s = smtplib.SMTP('smtp.office365.com', 587)
            s.starttls()
            s.login('vikass@booleandata.com', sender_email_id_password)
            text = msg.as_string()
            s.sendmail(msg['From'], msg['To'].split(","), text)
            s.quit()


        #     msg = MIMEMultipart()
        #     msg['From'] = 'sunilm@booleandata.com'
        #     msg['To'] = 'hitesh@booleandata.com,nagarjunas@booleandata.com,sunilm@booleandata.com'
        #
        #
        # s.sendmail(msg['From'], msg['To'].split(","), text)

        col1,col2 =st.columns(2)
        with col1:
            # if __name__ == '__main__':
            if st.form_submit_button("migrate"):
                data_load_state = st.text('Loading data...')

                start_of_process = datetime.now()
                # table_list = sqlserver_db_table_list()
                load_time_list = []
                validation_dataframes = pd.DataFrame(columns=['Table_Name', 'Sqlserver_Row_Count', 'Snowflake_Row_Count'])
                for table_name in sql_table_name:
                    print(table_name)
                    table_data_df = sqlserver_db_table_data_extraction(table_name)
                    snowflake_table_data_load(table_data_df, table_name)

                for table_name in sql_table_name:
                    final = sqlserver_validation_data(table_name)
                    frames = [validation_dataframes, final]
                    validation_dataframes = pd.concat(frames, axis=0, ignore_index=True)
                load_time_df = pd.DataFrame(load_time_list,
                                            columns=['aws_s3_filename', 'start_time', 'end_time', 'total_load_time'])
                validation_dataframes['Difference'] = validation_dataframes['Sqlserver_Row_Count'] - validation_dataframes[
                    'Snowflake_Row_Count']
                final_df = [validation_dataframes, load_time_df]
                final_result_df = pd.concat(final_df, axis=1)
                # # print(validation_dataframes)
                final_result_df.to_csv("Sqlserver_Data_Migration_Status.csv", index=False)
                # send_mail_notification("Redshift_validation_file.csv")
                end_of_process = datetime.now()
                print("total time taken for loading is", divmod((end_of_process - start_of_process).total_seconds(), 60))
                data_load_state.text(" ")
                for x in stqdm(range(len(sql_table_name)), backend=False):
                    for y in stqdm(range(15), desc=f"{sql_table_name[x]}"):
                        sleep(0.5)
                send_mail_notification("Sqlserver_Data_Migration_Status.csv")
                st.success('Data Sucessfully Migrated to Snowflake')
        with col2:
            if st.form_submit_button('Previous'):
                switch_page('target')

