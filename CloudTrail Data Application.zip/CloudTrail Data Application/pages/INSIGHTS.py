import alt as alt
import altair
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import yaml
from sqlalchemy import create_engine
from snowflake.sqlalchemy import URL
from streamlit_extras.metric_cards import style_metric_cards
import plotly.express as px
from streamlit_extras.mandatory_date_range import date_range_picker
from datetime import date
from streamlit_extras.switch_page_button import switch_page


with open('snowflake.yml') as file:
    doc = yaml.load(file, Loader=yaml.FullLoader)

selected_database=doc['selected_database']
selected_schema=doc['selected_schema']
st.markdown("""

<style>
[data-testid="stSidebarNav"]{
display: none;
}
</style>""",unsafe_allow_html=True)

with st.sidebar:
    st.image("https://5nnbe2.a2cdn1.secureserver.net/wp-content/uploads/2022/09/Boolean-logo_Boolean-logo-USA-1.png")
    st.markdown("<h1 style='text-align: center; color: #4566CE;'></h1>", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("<h1 style='text-align: center; color: #4566CE;'>ABOUT BOOLEAN DATA</h1>", unsafe_allow_html=True)
    st.write("""Boolean Data Systems is a specialized data services company that leverages cloud technologies 
    to help businesses effectively store and manage large amounts of data.
    We work with innovative technology solutions accessible to all to help clients stay ahead of the disruption cycle 
    by unlocking the hidden potential of data.
    Our Enterprise Data Services include Data Engineering, Data Science, and Analytics Services to assist our clients 
    in building reference architecture, migration use cases, analytics and different AI and ML models.
    At Boolean Data Systems, we integrate our technical expertise and cutting-edge analytics with a deeper
     understanding of potential consumers to help you stay ahead of your competitors.""")
    st.markdown("[Learn More>](https://booleandata.com//)")


st.title("Insights On AWS Logs Data")

# snowflake connection
account ='oseazbt-booleandata_partner'
UserName = 'akhilp@booleandata.com'
password = 'Mahidhoni07@&'


engine = create_engine(URL(
    account=account,
    user=UserName,
    password=password,

))
con = engine.connect()

# wh=con.execute(f"SHOW WAREHOUSES")
# warehouses = [row[0] for row in wh]
# selected_warehouse = st.selectbox('**Warehouse**', warehouses)
# col1,col2,col3 = st.columns(3)
# db=con.execute("SHOW DATABASES")
# DATABASES = [row[1] for row in db]
# selected_database = col1.selectbox('**DATABASE**', DATABASES)
#
#
# sc=con.execute("SHOW SCHEMAS")
# SCHEMAS = [row[1] for row in sc]
# selected_schema = col2.selectbox('**SCHEMA**', SCHEMAS)

# vw=con.execute("SHOW VIEWS")
# VIEWS = [row[1] for row in sc]
# selected_view = col3.selectbox('**VIEW**', VIEWS)


# col1,col2 = st.columns(2)

# Regions = pd.read_sql(f"""select * from "{selected_database}"."{selected_schema}"."MAIN_STREAMLIT_VIEW""",con)
# Regions =pd.read_sql(f"select  distinct(AWSREGION) from {selected_database}.{selected_schema}.MAIN_STREAMLIT_VIEW",con)
# reg = col1.selectbox('AWSREGION',Regions['awsregion'])
#
# Types = pd.read_sql(f"select distinct(TYPES) from {selected_database}.{selected_schema}.MAIN_STREAMLIT_VIEW",con)
# typ = col2.selectbox('TYPES',Types['types'])
#
# Bucket = pd.read_sql(f"select  distinct(BUCKETNAME)  from {selected_database}.{selected_schema}.MAIN_STREAMLIT_VIEW",con)
# buc = col3.selectbox('BUCKETNAME',Bucket['bucketname'])

col4,col5,col6 = st.columns(3)
Kpi1 = pd.read_sql(f"""select COUNT(DISTINCT AWSREGION) as Regions from {selected_database}.{selected_schema}.CLOUDTRAIL_VIEW""",con)
col4.metric(label='REGIONS',value=Kpi1['regions'])
style_metric_cards()

Kpi1 = pd.read_sql(f"""select  count(distinct(USERNAME)) as Users from {selected_database}.{selected_schema}.CLOUDTRAIL_VIEW""",con)
col5.metric(label='USERS',value=Kpi1['users'])
style_metric_cards()

Kpi1 = pd.read_sql(f"""select count(distinct(BUCKETNAME)) as S3_Buckets from {selected_database}.{selected_schema}.CLOUDTRAIL_VIEW""",con)
col6.metric(label='BUCKETS',value=Kpi1['s3_buckets'])
style_metric_cards()


####################

chart_6 = pd.read_sql(f"""SELECT EVENTNAME, AWSREGION, COUNT(EVENTID) AS no_of_events
FROM {selected_database}.{selected_schema}.CLOUDTRAIL_VIEW
GROUP BY EVENTNAME, AWSREGION
ORDER BY no_of_events DESC
LIMIT 10""", con)


region_list = chart_6["awsregion"].unique().tolist()
region_list.insert(0, "All Regions")
selected_region = st.selectbox("Select Region", region_list)

if selected_region == "All Regions":
    filtered_chart_6 = chart_6
else:
    filtered_chart_6 = chart_6[chart_6["awsregion"] == selected_region]

# Create the plot
chart = altair.Chart(filtered_chart_6).mark_bar().encode(
    x='eventname',
    y='no_of_events',
    color='awsregion',
    tooltip=['eventname', 'no_of_events']
).properties(
    title=f"Number Of Events Occurred In {selected_region}"
)

st.write(f"**AWS Event:** {filtered_chart_6.iloc[0]['eventname']}")

st.altair_chart(chart, use_container_width=True)

#############
result = date_range_picker("Select  Date Range")

# top_n_users = st.number_input("Select the number of users to display", min_value=1, max_value=100, value=10)

# Bytes_two = pd.read_sql(f"""select distinct BUCKETNAME, AWSREGION, date(EVENTTIME),
#             BYTESTRANSFERREDOUT
#             from {selected_database}.{selected_schema}.CLOUDTRAIL_VIEW
#             where USERNAME is not null and BYTESTRANSFERREDOUT is not null
#             and date(EVENTTIME) between '{result[0]}' and '{result[1]}'
#             """,con)
#
#
# region_list1 = Bytes_two["awsregion"].unique().tolist()
#
# selected_region1 = st.selectbox("Select Region",region_list1)
#
# if selected_region1 == "":
#     filtered_Bytes_two = Bytes_two
# else:
#     filtered_Bytes_two = Bytes_two[Bytes_two["awsregion"] == selected_region1]
#
# top_users = st.slider('Select Top Users', min_value=1, max_value=100, value=10)
# filtered_Bytes_two = filtered_Bytes_two.groupby(['awsregion', 'bucketname'])['bytestransferredout'].sum().reset_index()
# filtered_Bytes_two = filtered_Bytes_two.nlargest(top_users, 'bytestransferredout')
#
# fig = px.bar(Bytes_two, x="bucketname", y="bytestransferredout", color="awsregion")
#
# st.plotly_chart(fig)
# starting_date = st.date_input('Starting date', value=pd.to_datetime('2022-10-03'))
# ending_date = st.date_input('Ending date', value=pd.to_datetime('2023-04-05'))
#
# result = date_range_picker("Select Date Range ")
#
# regions = ['us-east-1', 'us-east-2', 'us-west-2', 'ap-south-1','ap-southeast-2',
#                'ap-south-2', 'ap-northeast-1', 'ap-southeast-2',  'eu-north-1']
#
# region_selection = st.selectbox("Select An AWS Region", regions)
#
# Bytes = pd.read_sql(f"""select distinct USERNAME, AWSREGION, date(EVENTTIME), sum(BYTESTRANSFERREDIN) as BYTESTRANSFERREDIN,
#             sum(BYTESTRANSFERREDOUT) as BYTESTRANSFERREDOUT from {selected_database}.{selected_schema}.CLOUDTRAIL_VIEW
#             where USERNAME is not null and AWSREGION = '{region_selection}' and date(EVENTTIME)
#             between '{result[0]}' and '{result[1]}'
#             group by USERNAME, AWSREGION, EVENTTIME""",con)
#
# df_Bytes = pd.DataFrame(Bytes)
# figl = px.bar(df_Bytes,x='username',y='bytestransferredin',color='awsregion',title=f"USERS BYTESTRANSFERREDIN BY REGION WISE ({region_selection})")
# st.plotly_chart(figl)

##########################

# result = date_range_picker("Select Date Range      ",max_date=date.today())
#
#
# sc_line = pd.read_sql(f""" SELECT username, COUNT(CONSOLELOGIN) AS console_login
#     FROM {selected_database}.{selected_schema}.CLOUDTRAIL_VIEW
#     WHERE CONSOLELOGIN IS NOT NULL
#     AND DATE(EVENTTIME) BETWEEN '{result[0]}' AND '{result[1]}'
#     GROUP BY username""",con)
#
#
# fig22 = px.bar(sc_line, x="username", y="console_login", color="username",
#                title="Number Of Times That User Logged In AWS Console")
# fig22.update_layout(showlegend=False)
# st.plotly_chart(fig22)

#######

users = pd.read_sql("""SELECT DISTINCT USERNAME FROM "DEVELOPER_DB"."CLOUDTRAIL_APP"."COULDTRAIL_VIEW" WHERE MFAUSED IS NOT NULL""", con)

# Create a drop-down list of users
selected_user = st.selectbox("Select User  ", users)

# Query the database to get the MFA usage of the selected user
df_chart = pd.read_sql(f"""SELECT  USERNAME,MFAUSED 
                            FROM {selected_database}.{selected_schema}.CLOUDTRAIL_VIEW
                            WHERE USERNAME = '{selected_user}' AND MFAUSED IS NOT NULL 
                            GROUP BY USERNAME,MFAUSED """, con)

fig = altair.Chart(df_chart).mark_bar().encode(
    x="username",
    y="mfaused",
    color='mfaused',
).properties(
    title=f'Status Of MFA Used By User {selected_user.split("@")[0]}'
)

st.altair_chart(fig, use_container_width=True)


###################
error_chart = pd.read_sql(f"""select USERNAME,ERRORCODE, count(ERRORCODE) as No_of_times_faced from 
{selected_database}.{selected_schema}.CLOUDTRAIL_VIEW
group by ERRORCODE,USERNAME
order by No_of_times_faced desc""",con)

efig = px.bar(error_chart, x='username', y='errorcode', color='errorcode',orientation='h',
              title="Which Error Was Faced Most Of The Times")

st.plotly_chart(efig)

#############
top_n_buckets = st.number_input("Select The Number Of Top Buckets To Display", min_value=1, max_value=100, value=10)

chart_4 = pd.read_sql(f"""select  distinct(BUCKETNAME),count(EVENTID) as no_of_events
from {selected_database}.{selected_schema}.CLOUDTRAIL_VIEW
where BUCKETNAME is not Null  group by BUCKETNAME,username
order by no_of_events desc limit {top_n_buckets}""",con)

fig4 = px.bar(chart_4, x='no_of_events', y='bucketname', orientation='h', color='bucketname',
              title="Which Bucket Has Been Used Mostly")
fig4.update_layout(showlegend=False)
st.plotly_chart(fig4)

#####################################
Top_n_Users = st.number_input("Select The Number Of User", min_value=1, max_value=100, value=10)

unauth = pd.read_sql(f"""select USERNAME,count(*) as no_of_unauthorized_api_calls from 
{selected_database}.{selected_schema}.CLOUDTRAIL_VIEW
where errorCode in ('AccessDenied', 'UnauthorizedOperation') and USERNAME is Not Null
and sourceIPAddress != 'delivery.logs.amazonaws.com'
and eventName != 'HeadBucket'
group by USERNAME
order by no_of_unauthorized_api_calls desc limit {Top_n_Users}""", con)

fig = px.bar(unauth, x='no_of_unauthorized_api_calls', y='username', orientation='h',
             labels={'no_of_unauthorized_api_calls': 'Number of Unauthorized API Calls', 'USERNAME': 'Username'},
             title='How Many Unauthorized API Calls Has Been Made By A User')
fig.update_traces(marker_color='#636EFA')

st.plotly_chart(fig)

#####################################

bytesin = pd.read_sql(f"""select distinct BUCKETNAME,BYTESTRANSFERREDIN as Transferred_In_Bytes from 
{selected_database}.{selected_schema}.CLOUDTRAIL_VIEW where BUCKETNAME IS NOT NULL 
and  BYTESTRANSFERREDIN <> '0'
order by Transferred_In_Bytes """,con)

fig22 = px.pie(bytesin,values='transferred_in_bytes', names='bucketname',title='Which Bucket Has More storage In Bytes')
st.plotly_chart(fig22)

# fig = px.pie(bytesin, values='transferred_in_bytes', names='bucketname', hole=0.5,
#              title='Which Bucket Has More storage In Bytes')
# fig.update_traces(textposition='inside', textinfo='percent+label')
# st.plotly_chart(fig)

###################

bytesout = pd.read_sql(f"""SELECT DISTINCT BUCKETNAME, BYTESTRANSFERREDOUT AS Transferred_Out_Bytes
FROM {selected_database}.{selected_schema}.CLOUDTRAIL_VIEW
WHERE BYTESTRANSFERREDOUT IS NOT NULL AND BUCKETNAME IS NOT NULL 
ORDER BY Transferred_Out_Bytes DESC""",con)

fig11 = px.bar(bytesout, x="bucketname", y="transferred_out_bytes", color='bucketname',width=600,height=700,
              title='Which Bucket Has Been Transferred_Out more data In Bytes')
fig11.update_layout(xaxis={"categoryorder": "total descending"})
fig11.update_layout(showlegend=False)
st.plotly_chart(fig11)

#############

readon = pd.read_sql(f"""select distinct READONLY,EVENTNAME,USERNAME 
from {selected_database}.{selected_schema}.CLOUDTRAIL_VIEW
where USERNAME is not null""",con)

fig91 = px.bar(readon, x='username', y='eventname', color='readonly')
fig91.update_layout(xaxis={"categoryorder": "total descending"})
st.plotly_chart(fig91)

if st.button("Previous"):
    switch_page("DATAMIGRATION")



################
# chart_9 = pd.read_sql(f"""select CONSOLELOGIN, count(CONSOLELOGIN) as login_count, USERNAME
#                           from "DEVELOPER_DB"."CLOUDTRAIL_APP"."COULDTRAIL_VIEW"
#                           where CONSOLELOGIN is not null
#                           group by CONSOLELOGIN, USERNAME""", con)
#
# # Create donut chart
# fig = px.pie(chart_9, values='login_count', names='username',
#              hole=0.5, color='username',hover_data=['consolelogin'],
#              title='Console Login Success/Failure by User')
#
# # Show chart in Streamlit
# st.plotly_chart(fig)