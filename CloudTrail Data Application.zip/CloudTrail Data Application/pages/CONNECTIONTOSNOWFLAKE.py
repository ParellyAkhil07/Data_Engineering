import snowflake.connector
import snowflake.connector
import time
import streamlit as st
import yaml
from sqlalchemy import create_engine
from snowflake.sqlalchemy import URL
from streamlit_extras.switch_page_button import switch_page

st.markdown("""

<style>
[data-testid="stSidebarNav"]{
display: none;
}
</style>""",unsafe_allow_html=True)
with st.sidebar:
    st.image("https://5nnbe2.a2cdn1.secureserver.net/wp-content/uploads/2022/09/Boolean-logo_Boolean-logo-USA-1.png")
    st.markdown("<h1 style='text-align: center; color: #4566CE;'></h1>", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("<h1 style='text-align: center; color: #4566CE;'>ABOUT BOOLEAN DATA</h1>", unsafe_allow_html=True)
    st.write("""Boolean Data Systems is a specialized data services company that leverages cloud technologies 
    to help businesses effectively store and manage large amounts of data.
    We work with innovative technology solutions accessible to all to help clients stay ahead of the disruption cycle 
    by unlocking the hidden potential of data.
    Our Enterprise Data Services include Data Engineering, Data Science, and Analytics Services to assist our clients 
    in building reference architecture, migration use cases, analytics and different AI and ML models.
    At Boolean Data Systems, we integrate our technical expertise and cutting-edge analytics with a deeper
     understanding of potential consumers to help you stay ahead of your competitors.""")
    st.markdown("[Learn More>](https://booleandata.com//)")

st.markdown("""
    <style>
        .logo {
            float: left;
            margin-right: 10px;
            margin-bottom: 10px;
            width: 150px;
        }
    </style>
""", unsafe_allow_html=True)

st.markdown('<img class="logo" src="https://mma.prnewswire.com/media/552340/Snowflake_logo_Logo.jpg?p=facebook">', unsafe_allow_html=True)




# s3 = boto3.resource('s3', aws_access_key_id=aws_access_key_id,aws_secret_access_key=aws_secret_access_key)

st.markdown('<h1 style="color:blue; font-size: 24px;">SNOWFLAKE CONNECTION</h1>', unsafe_allow_html=True)


username = st.text_input('USERNAME', 'akhilp@booleandata.com')
password = st.text_input('PASSWORD', 'Mahidhoni07@&', type='password')
account = st.text_input('ACCOUNT', 'oseazbt-booleandata_partner')

engine = create_engine(URL(
        account=account,
        user=username,
        password=password,
    ))

connection = engine.connect()
col1,col2 = st.columns(2)
if col2.button("connect"):
    if connection:
        st.success("Successfully Connected To Snowflake")
        time.sleep(2)
        switch_page("DATAMIGRATION")
    else:
        st.error("check the login credentials")

if col1.button("Previous"):
    switch_page("AWSCONNECTION")


# data = dict(
# snowflake_user = username,
# snowflake_password = password,
# snowflake_account = account,
#
# )
#
# with open('snowflake.yml', 'w') as outfile:
#     yaml.dump(data, outfile, default_flow_style=False)
#
# with open(r'snowflake.yml') as file:
#     doc = yaml.load(file, Loader=yaml.FullLoader)
# snowflake_user = doc["snowflake_user"]
# snowflake_password = doc["snowflake_password"]
# snowflake_account = doc["snowflake_account"]



# if st.button("Connect"):
#     try:
#         @st.cache_resource
#         def init_connection():
#             return snowflake.connector.connect(
#                 **st.secrets["snowflake"], client_session_keep_alive=True
#             )
#
#         conn = init_connection()
#         if conn:
#             st.success("Successfully connected to Snowflake")
#             time.sleep(2)
#             switch_page('DATAMIGRATION') # page switching code moved here
#         else:
#             st.error("Could not connect to Snowflake")
#     except snowflake.connector.errors.ProgrammingError:
#         st.error("Please check your login credentials")
#


    # except botocore.exceptions.BotoCoreError:
    #     st.error("An error occurred while connecting to AWS. Please try again later.")







# if st.button("Connect"):
#     try:
#         @st.cache_resource
#         def init_connection():
#             return snowflake.connector.connect(
#                 **st.secrets["snowflake"], client_session_keep_alive=True
#             )
#
#
#         conn = init_connection()
#         if conn:
#             st.success("Successfully connected to Snowflake")
#             time.sleep(2)
#             switch_page('AWS')
#     except snowflake.connector.errors.ProgrammingError:
#         st.error("Please check your login credentials")












#Use AWS services
# s3 = session.client("s3")
# response = s3.list_buckets()
#
# # Display results in Streamlit app
# st.write("S3 Buckets:")
# for bucket in response["Buckets"]:
#     st.write(f"- {bucket['Name']}")

#






#
# # Get the object from the S3 bucket
# objects = s3.Bucket(bucket_name).objects.filter(Prefix=prefix)
#
# for obj in objects:
#     if obj.key.endswith('/') or not obj.key.endswith('.json.gz'):
#         continue
#
# file_content = obj.get()['Body'].read()
#
# uncompressed_content = gzip.decompress(file_content)
#
# json_content = json.loads(uncompressed_content)
#
# print('s3 connection successfully created')
#
#
#
# def create_snowpipe():
#     df = pd.DataFrame(json_content)
#     with engine.begin() as conn:
#         df.head(0).to_sql('cloudtrail_ingestion',con=conn,if_exists='replace',index=False,schema=snowflake_schema)
#
#         conn.execute(f"""create or replace file format cloudformat type = json""")
#         print("file format created successfully")
#
#         conn.execute(f"""create or replace stage cloudtrail_logs_staging
#         url = 's3://aws-cloudtrail-logs-627741535532-25b75324/AWSLogs/'
#         storage_integration = s3_int_cloudtrail_logs
#         file_format = cloudformat""")
#         print("stage created successfully")
#
#         conn.execute(f"""create or replace pipe cloudtrail_pipe  auto_ingest=true
#             as
#             copy into CLOUDTRAIL_INGESTION
#             from @cloudtrail_logs_staging
#             file_format = (type = json)
#             match_by_column_name = case_insensitive
#             on_error = 'continue'
#         """)
#         print("Pipe created successfully")
#
#         conn.execute(f"""alter pipe cloudtrail_pipe refresh""")
#
#         print("Pipe altered successfully")
#
#         conn.execute("""create or replace view cloudtrail as
#         select
#         VALUE:eventTime::TIMESTAMP as eventTime,
#         VALUE:eventVersion::string as eventVersion,
#         VALUE:userIdentity::variant as userIdentity,
#         VALUE:eventSource::string as eventSource,
#         VALUE:eventName::string as eventName,
#         VALUE:awsRegion::string as awsRegion,
#         VALUE:sourceIPAddress::string as sourceIPAddress,
#         VALUE:userAgent::string as userAgent,
#         VALUE:errorCode::string as errorCode,
#         VALUE:errorMessage::string as errorMessage,
#         VALUE:requestParameters::variant as requestParameters,
#         VALUE:responseElements::variant as responseElements,
#         VALUE:additionalEventData::variant as additionalEventData,
#         VALUE:requestID::string as requestID,
#         VALUE:eventID::string as eventID,
#         VALUE:eventType::string as eventType,
#         VALUE:apiVersion::string as apiVersion,
#         VALUE:managementEvent::variant as managementEvent,
#         VALUE:resources::variant as resources,
#         VALUE:recipientAccountId::string as recipientAccountId,
#         VALUE:serviceEventDetails::variant as serviceEventDetails,
#         VALUE:sharedEventID::string as sharedEventID,
#         VALUE:eventCategory::string as eventCategory,
#         VALUE:vpcEndpointId::string as vpcEndpointId,
#         VALUE:addendum::string as addendum,
#         VALUE:sessionCredentialFromConsole::string as sessionCredentialFromConsole,
#         VALUE:edgeDeviceDetails::string as edgeDeviceDetails,
#         VALUE:tlsDetails::variant as tlsDetails,
#         VALUE:insightDetails::variant as insightDetails
#       from public.cloudtrail_raw , LATERAL FLATTEN(input => record:Records)""")
#
#         print("Data converted")
#
#         print(100 * '*')
#
# create_snowpipe()
