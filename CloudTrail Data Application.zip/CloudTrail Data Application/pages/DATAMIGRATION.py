import time
import pandas as pd
import pathlib
import os
import snowflake.connector
import yaml
from snowflake.connector.pandas_tools import write_pandas
from snowflake.connector.pandas_tools import pd_writer
import boto3
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
from snowflake.sqlalchemy import URL
from sqlalchemy import column
from sqlalchemy import table, column
import glob
import os.path
import json
import gzip
import streamlit as st
from PIL import Image
from botocore.exceptions import NoCredentialsError
import boto3.session
from streamlit_extras.switch_page_button import switch_page



# accesskey = st.text_input('aws_access_key_id' ,'AKIAZEKCPVUWBQ7P2PZH')
# secretkey = st.text_input('aws_secret_access_key','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')
st.markdown("""

<style>
[data-testid="stSidebarNav"]{
display: none;
}
</style>""",unsafe_allow_html=True)

st.title("AWS Cloudtrail Ingestion Architecture")
st.image("https://quickstarts.snowflake.com/guide/cloudtrail_log_ingestion/img/fb71e42eabdfee65.png")

st.sidebar.image("https://1.bp.blogspot.com/-kSwUEtMavFE/X7p2D-GwkII/AAAAAAAABmk/QGBnpES85GwcOYfZZ3mTJN3WN36Uf15BQCLcBGAsYHQ/s1368/1.png")

st.sidebar.title("ABOUT AWS CLOUDTRAIL")
with st.sidebar:
    st.write("""AWS CloudTrail is an AWS service that helps you enable operational and risk auditing, governance,
    and compliance of your AWS account. Actions taken by a user, role, or an AWS service are recorded as events in 
    CloudTrail. Events include actions taken in the AWS Management Console, AWS Command Line Interface, and AWS SDKs 
    and APIs. By ingesting and analyzing these logs in Snowflake, practitioners are able to gain analytical insights 
    and work toward securing their environments at scale.""")
    st.markdown("[Learn More>](https://quickstarts.snowflake.com/guide/cloudtrail_log_ingestion/index.html?index=..%2F..index#0)")

access_key = 'AKIAZEKCPVUWBQ7P2PZH'
secret_key = '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'

S3 = boto3.resource('s3',aws_access_key_id = access_key,aws_secret_access_key = secret_key)

bucket_names = [bucket.name for bucket in S3.buckets.all()]

selected_bucket_name = st.selectbox('SELECT A BUCKET', bucket_names)

my_bucket = S3.Bucket(selected_bucket_name)


json_keys = [obj.key for obj in my_bucket.objects.all() if obj.key.endswith('.json.gz')] # display the json files


# Display JSON file keys in a dropdown
selected_json_key = st.multiselect('SELECT A JSON FILE', json_keys)

for x in range(len(selected_json_key)):
    obj = my_bucket.Object(selected_json_key[x])

    data = obj.get()['Body'].read()

                    # Uncompress the data
    data = gzip.decompress(data)

                    # Load the JSON data
    json_data = json.loads(data)

                    # Display the JSON data
    #st.json(json_data)
    actual_data = pd.concat([pd.json_normalize(json_data) for json_content in json_keys], ignore_index=True)
    #st.write(actual_data)
    #df=pd.DataFrame(actual_data)
    # st.write(df)


# if st.button('s3_connection'):
#     if S3:
#         st.success('s3 connection successfully created')
#         switch_page('snowflake_connection')
#     else:
#         st.error('s3 connection error')

# snowflake connection
account ='oseazbt-booleandata_partner'
UserName = 'akhilp@booleandata.com'
password = 'Mahidhoni07@&'


engine = create_engine(URL(
    account=account,
    user=UserName,
    password=password,

))
con = engine.connect()


# w = con.execute("SHOW WAREHOUSES")
# warehouses = pd.DataFrame(w)
# warehouses = warehouses['name'].unique()
# # Warehouses = [row[0] for row in con]
# selected_warehouse = st.selectbox('**Warehouse**', warehouses)
wh=con.execute(f"SHOW WAREHOUSES")
warehouses = [row[0] for row in wh]
selected_warehouse = st.selectbox('**WAREHOUSE**', warehouses)

db=con.execute("SHOW DATABASES")
DATABASES = [row[1] for row in db]
selected_database = st.selectbox('**DATABASE**', DATABASES)


sc=con.execute("SHOW SCHEMAS")
SCHEMAS = [row[1] for row in sc]
selected_schema = st.selectbox('**SCHEMA**', SCHEMAS)

data = dict(
selected_database=selected_database,
selected_schema=selected_schema,
)



with open('snowflake.yml', 'w') as outfile:
    yaml.dump(data, outfile, default_flow_style=False)

# con.execute("SHOW DATABASES")
# databases = [row[1] for row in con]
# selected_database = st.selectbox('**Database**', databases)
#
#
#
# con.execute("SHOW SCHEMAS")
# SCHEMAS = [row[1] for row in con]
# selected_schema = st.selectbox('**SCHEMA**', SCHEMAS)
#
con.execute(f"USE WAREHOUSE {selected_warehouse}")
con.execute(f"USE DATABASE {selected_database}")
con.execute(f"USE SCHEMA {selected_schema}")
col1,col2=st.columns(2)
if col2.button('Migrate Data To Snowflake'):

    con.execute(f"create or replace table {selected_database}.{selected_schema}.AWS_LOGS_DATA (record VARIANT)")

    #st.success("table created sucessfully")

    con.execute(f"""create or replace file format {selected_database}.{selected_schema}.main_streamlit_fileformat
    type = json """)

    #st.success("fileformat created sucessfully")

    con.execute(f"""create or replace stage main_streamlit_stage
    storage_integration = s3_int_cloudtrail_logs_data
    url='s3://aws-cloudtrail-logs-627741535532-25b75324/AWSLogs/'""")

    #st.success("stage created sucessfully")

    con.execute(f"""create or replace pipe main_streamlit_snowpipe auto_ingest=TRUE
                                as
                                copy into AWS_LOGS_DATA ("RECORD")
                                from @main_streamlit_stage
                                file_format = main_streamlit_fileformat
                                on_error = 'CONTINUE' """)

    #st.success("snowpipe created sucessfully")

    con.execute(f"""alter pipe main_streamlit_snowpipe refresh""")


    con.execute(f""" create or replace view {selected_database}.{selected_schema}."CLOUDTRAIL_VIEW" as
select
 s.VALUE:additionalEventData.LoginTo::varchar as LoginTo,
                                    s.VALUE:additionalEventData.AuthenticationMethod::varchar as AuthenticationMethod,
                                    s.VALUE:additionalEventData.CipherSuite::varchar as AE_CipherSuite,
                                    s.VALUE:additionalEventData.SignatureVersion::varchar as SignatureVersion,
                                    s.VALUE:additionalEventData.bytesTransferredIn::varchar as bytesTransferredIn,
                                    s.VALUE:additionalEventData.bytesTransferredOut::varchar as bytesTransferredOut,
                                    s.VALUE:additionalEventData.MFAUsed::varchar as MFAUsed,
                                    s.VALUE:additionalEventData.MfaType::varchar as MfaType,
                                    s.VALUE:additionalEventData.MobileVersion::varchar as MobileVersion,
                                    s.VALUE:awsRegion::varchar as awsRegion,
                                    s.VALUE:errorCode::varchar as errorCode,
                                    s.VALUE:errorMessage::varchar as errorMessage,
                                    s.VALUE:eventCategory::varchar as eventCategory,
                                    s.VALUE:eventID::varchar as eventID,
                                    s.VALUE:eventName::varchar as eventName,
                                    s.VALUE:eventSource::varchar as eventSource,
                                    s.VALUE:eventTime::varchar as eventTime,
                                    s.VALUE:eventType::varchar as eventType,
                                    s.VALUE:eventVersion::varchar as eventVersion,
                                    s.VALUE:apiVersion::string as apiVersion,
                                    s.VALUE:managementEvent::varchar as managementEvent,
                                    s.VALUE:readOnly::varchar as readOnly,
                                    s.VALUE:recipientAccountId::varchar as recipientAccountId,
                                    s.VALUE:sharedEventID::string as sharedEventID,
                                    s.VALUE:requestID::varchar as requestID,
                                    s.VALUE:requestParameters.Host::varchar as Host,
                                    s.VALUE:requestParameters:bucketName::varchar as bucketName,
                                    s.VALUE:requestParameters:location::varchar as location,
                                    s.VALUE:responseElements.ConsoleLogin::varchar as ConsoleLogin,
                                    s.VALUE:responseElements.CheckMfa::varchar as CheckMfa,
                                    s.VALUE:responseElements:assumedRoleUser:arn::varchar as assumedRoleUser_arn,
                                    s.VALUE:responseElements:assumedRoleUser:assumedRoleId::varchar as assumedRoleId,
                                    s.VALUE:responseElements:credentials:accessKeyId::varchar as RE_accessKeyId,
                                    s.VALUE:responseElements:credentials:expiration::varchar as expiration,
                                    s.VALUE:responseElements:credentials:sessionToken::varchar as sessionToken,
                                    s.VALUE:sessionCredentialFromConsole::varchar as sessionCredentialFromConsole,
                                    s.VALUE:sourceIPAddress::varchar as sourceIPAddress,
                                    s.VALUE:tlsDetails.cipherSuite::varchar as cipherSuite,
                                    s.VALUE:tlsDetails.clientProvidedHostHeader::varchar as clientProvidedHostHeader,
                                    s.VALUE:tlsDetails.tlsVersion::varchar as tlsVersion,
                                    s.VALUE:userAgent::varchar as userAgent,
                                    s.VALUE:userIdentity.accessKeyId::varchar as accessKeyId,
                                    s.VALUE:userIdentity:invokedBy::varchar AS invokedBy,
                                    s.VALUE:userIdentity.accountId::varchar as accountId,
                                    s.VALUE:userIdentity.arn::varchar as arn,
                                    s.VALUE:userIdentity.principalId::varchar as principalId,
                                    s.VALUE:userIdentity.sessionContext.attributes.creationDate::TIMESTAMP as 								creationDate,
                                    s.VALUE:userIdentity.sessionContext.attributes.mfaAuthenticated::varchar as 								mfaAuthenticated,
                                    s.VALUE:userIdentity.type::varchar as type,
                                    s.VALUE:userIdentity.userName::Varchar as userName,
                                    s.VALUE:vpcEndpointId::Varchar as vpcEndpointId
                                    from AWS_LOGS_DATA,
                                    LATERAL FLATTEN(input => record:Records) as s """)

    st.success("Data Migrated To Snowflake Successfully")
    time.sleep(20)

    switch_page('INSIGHTS')

if col1.button("Previous"):
    switch_page("CONNECTIONTOSNOWFLAKE")

# st.success("snowflake view created sucessfully")



    # vw = con.execute("SHOW VIEWS")
    # VIEWS = [row[1] for row in sc]
    # selected_view = st.selectbox('**VIEWS**', VIEWS)
    #
    # con.execute(f"USE VIEW{selected_view}")
    #
    # st.success("Successfully Converted Data Into Structured Format")
    # time.sleep(5)



# if st.button('Snowflake connection'):
#
#     if con:
#             st.success('s3 connnection sucessfully created')
#     else:
#             st.error('s3 connection worng')