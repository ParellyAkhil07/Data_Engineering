import pathlib
import time
import botocore.exceptions
import boto3
import os
import streamlit as st
from streamlit_extras.switch_page_button import switch_page

st.markdown("""

<style>
[data-testid="stSidebarNav"]{
display: none;
}
</style>""",unsafe_allow_html=True)
st.image("https://d1.awsstatic.com/logos/aws-logo/full-color/AWS-Logo_Full-Color_1000x600.23165eb2b9af9cc8e068e74fbabc28222d091298.png", width=150)

st.title("CLOUDTRAIL ANALYTICS")

with st.sidebar:
    st.image("https://5nnbe2.a2cdn1.secureserver.net/wp-content/uploads/2022/09/Boolean-logo_Boolean-logo-USA-1.png")
    st.markdown("<h1 style='text-align: center; color: #4566CE;'></h1>", unsafe_allow_html=True)


with st.sidebar:
    st.markdown("<h1 style='text-align: center; color: #4566CE;'>ABOUT BOOLEAN DATA</h1>", unsafe_allow_html=True)
    st.write("""Boolean Data Systems is a specialized data services company that leverages cloud technologies 
    to help businesses effectively store and manage large amounts of data.
    We work with innovative technology solutions accessible to all to help clients stay ahead of the disruption cycle 
    by unlocking the hidden potential of data.
    Our Enterprise Data Services include Data Engineering, Data Science, and Analytics Services to assist our clients 
    in building reference architecture, migration use cases, analytics and different AI and ML models.
    At Boolean Data Systems, we integrate our technical expertise and cutting-edge analytics with a deeper
     understanding of potential consumers to help you stay ahead of your competitors.""")
    st.markdown("[Learn More>](https://booleandata.com//)")

st.markdown("""
    <style>
        .logo {
            float: left;
            margin-right: 10px;
            margin-bottom: 10px;
            width: 150px;
        }
    </style>
""", unsafe_allow_html=True)

# st.markdown('<img class="logo" src="https://5nnbe2.a2cdn1.secureserver.net/wp-content/
# uploads/2022/09/Boolean-logo_Boolean-logo-USA-1.png">', unsafe_allow_html=True)


# st.markdown('<h1 style="color:blue; font-size: 36px;">BOOLEAN DATA SYSTEMS</h1>', unsafe_allow_html=True)

st.markdown('<h1 style="color:orange; font-size: 24px;">AWS CONNECTION</h1>', unsafe_allow_html=True)

# Read parameters from file
parm_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), f"../../cloudtrial.params")
param_file_path = pathlib.Path(parm_file)
parameters = {}
if param_file_path.exists():
    file_obj = open(parm_file)
    for line in file_obj:
        line = line.strip()
        if not line.startswith('#'):
            key_value = line.split('=')
            if len(key_value) == 2:
                parameters[key_value[0].strip()] = key_value[1].strip()


# Connect to AWS
access_key = st.text_input('ACCESS_KEY', 'AKIAZEKCPVUWBQ7P2PZH')
secret_key = st.text_input('SECRET_KEY', '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', type='password')
region_name = st.text_input('REGION', 'us-east-1')

if st.button("Connect"):
    try:
        session = boto3.Session(
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region_name
        )
        client = session.client('cloudtrail')
        response = client.describe_trails()
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            st.success("Successfully Connected To AWS")
            time.sleep(2)
            switch_page('CONNECTIONTOSNOWFLAKE')
        else:
            st.error("Could not connect to AWS")
    except botocore.exceptions.NoCredentialsError:
        st.error("Please check your AWS credentials")
    except botocore.exceptions.EndpointConnectionError:
        st.error("Could not connect to the specified region. Please check the region name.")

#
# s3_bucket = 's3_bucket_name'
# cloudtrail_log_prefix = 'cloudtrail_log_prefix'
#
# session = boto3.Session(region_name=region_name)
# s3_client = session.client('s3')
#
# # CloudTrail log files in the S3 bucket
# log_files = []
# result = s3_client.list_objects_v2(Bucket=s3_bucket, Prefix=cloudtrail_log_prefix)
# for obj in result.get('Contents', []):
#     log_files.append(obj.get('Key'))
#
# # log file and insert the events into Snowflake
# for log_file in log_files:
#     s3_object = s3_client.get_object(Bucket=s3_bucket, Key=log_file)
#     s3_data = s3_object['Body'].read().decode('utf-8')
#     cloudtrail_events = json.loads(s3_data)['Records']

#     # for event in cloudtrail_events:
#     #     # Extract relevant fields from the event
#     #     event_time = event['eventTime']
#     #     event_name = event['eventName']
#     #     event_source = event['eventSource']
#         # Add more fields as needed
#
#         # cursor = conn.cursor()
#         # cursor.execute(f"INSERT INTO {snowflake_table} (event_time, event_name, event_source) VALUES ('{event_time}', '{event_name}', '{event_source}')")
#         # cursor.close()
#
